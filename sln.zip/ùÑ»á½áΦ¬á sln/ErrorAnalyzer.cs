﻿using Proga1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;

namespace Proga1
{
    public class ErrorAnalyzer
    {
        public List<ErrorGroup> GroupErrors(List<BuildError> errors)
        {
            var groups = errors
                .GroupBy(e => e.ErrorType)
                .Select(g => new ErrorGroup
                {
                    GroupName = g.Key,
                    Description = $"Тип ошибки: {g.Key}",
                    ErrorCount = g.Count(),
                    Errors = g.ToList()
                })
                .OrderByDescending(g => g.ErrorCount)
                .ToList();

            return groups;
        }

        public Dictionary<string, int> GetLanguageStatistics(List<BuildError> errors)
        {
            return errors
                .GroupBy(e => e.Language)
                .ToDictionary(g => g.Key, g => g.Count());
        }
        public string GenerateStatisticsReport(List<BuildError> errors)
        {
            return BuildErrorStatistics.GenerateFullReport(errors);
        }

        public void SaveStatisticsReport(List<BuildError> errors, string filePath)
        {
            string report = BuildErrorStatistics.GenerateFullReport(errors);
            BuildErrorStatistics.SaveReportToFile(report, filePath);
            MessageBox.Show($"Отчет сохранен в {filePath}", "Сохранение отчета");
        }

        public List<string> GetPossibleCauses(List<BuildError> errors)
        {
            return BuildErrorStatistics.DetectPossibleCausesOfErrors(errors);
        }
    }

    public static class ErrorAnalyzerExtensions
    {
        public static List<ErrorGroup> GroupErrorsByType(this ErrorAnalyzer analyzer, List<BuildError> errors, string groupBy = "ErrorType")
        {
            List<ErrorGroup> result = new List<ErrorGroup>();

            switch (groupBy.ToLower())
            {
                case "errortype":
                    return analyzer.GroupErrors(errors); 

                case "language":
                    var byLanguage = errors
                        .GroupBy(e => e.Language)
                        .Select(g => new ErrorGroup
                        {
                            GroupName = g.Key,
                            Description = $"Язык: {g.Key}",
                            ErrorCount = g.Count(),
                            Errors = g.ToList()
                        })
                        .OrderByDescending(g => g.ErrorCount)
                        .ToList();
                    return byLanguage;

                case "typelanguage":
                    var byTypeAndLanguage = errors
                        .GroupBy(e => new { Type = e.ErrorType, Lang = e.Language })
                        .Select(g => new ErrorGroup
                        {
                            GroupName = $"{g.Key.Type} ({g.Key.Lang})",
                            Description = $"Ошибки {g.Key.Type} в {g.Key.Lang}",
                            ErrorCount = g.Count(),
                            Errors = g.ToList()
                        })
                        .OrderByDescending(g => g.ErrorCount)
                        .ToList();
                    return byTypeAndLanguage;

                case "date":
                    var byDate = errors
                        .GroupBy(e => e.Timestamp.Date)
                        .Select(g => new ErrorGroup
                        {
                            GroupName = g.Key.ToShortDateString(),
                            Description = $"Ошибки от {g.Key.ToShortDateString()}",
                            ErrorCount = g.Count(),
                            Errors = g.ToList()
                        })
                        .OrderByDescending(g => DateTime.Parse(g.GroupName)) 
                        .ToList();
                    return byDate;

                default:
                    return analyzer.GroupErrors(errors);
            }
        }

        public static List<BuildError> FilterErrors(this ErrorAnalyzer analyzer, List<BuildError> errors, string filterType = null, string filterValue = null)
        {
            if (string.IsNullOrEmpty(filterType) || string.IsNullOrEmpty(filterValue))
                return errors;

            switch (filterType.ToLower())
            {
                case "errortype":
                    return errors.Where(e => e.ErrorType.ToLower().Contains(filterValue.ToLower())).ToList();

                case "language":
                    return errors.Where(e => e.Language.ToLower().Contains(filterValue.ToLower())).ToList();

                case "packagename":
                    return errors.Where(e => e.PackageName.ToLower().Contains(filterValue.ToLower())).ToList();

                case "logmessage":
                    return errors.Where(e => e.LogMessage.ToLower().Contains(filterValue.ToLower())).ToList();

                case "date":
                    if (DateTime.TryParse(filterValue, out DateTime date))
                        return errors.Where(e => e.Timestamp.Date == date.Date).ToList();
                    break;
            }

            return errors;
        }

    }

}