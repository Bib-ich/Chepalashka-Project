﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Windows;
using HtmlAgilityPack;
using System.Linq;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.IO;
using System.Windows.Controls;

namespace Proga1
{
    

    public class ApiService
    {
        private readonly HttpClient _httpClient;

        
        private const string LogsUrl = "https://git.altlinux.org/beehive/logs/Sisyphus/";
        private const string PackagesUrl = "https://packages.altlinux.org/ru/sisyphus/";
        private const string ApiUrl = "https://rdb.altlinux.org/api/";
        private Dictionary<string, string> logAnalysisCache = new Dictionary<string, string>();
        public ApiService()
        {
            _httpClient = new HttpClient();
            _httpClient.DefaultRequestHeaders.Add("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36");
            _httpClient.Timeout = TimeSpan.FromSeconds(60);
        }
        
        public List<ErrorGroup> GroupErrors(List<BuildError> errors, string groupBy = "ErrorType")
        {
            var result = new List<ErrorGroup>();

            switch (groupBy.ToLower())
            {
                case "errortype":
                    var byType = errors
                        .GroupBy(e => e.ErrorType)
                        .Select(g => new ErrorGroup
                        {
                            GroupName = g.Key,
                            Description = $"Тип ошибки: {g.Key}",
                            ErrorCount = g.Count(),
                            Errors = g.ToList()
                        })
                        .OrderByDescending(g => g.ErrorCount)
                        .ToList();
                    result.AddRange(byType);
                    break;

                case "errorsubtype":
                    
                    var bySubType = errors
                        .GroupBy(e => GetErrorSubType(e))
                        .Select(g => new ErrorGroup
                        {
                            GroupName = g.Key,
                            Description = $"Подтип ошибки: {g.Key}",
                            ErrorCount = g.Count(),
                            Errors = g.ToList()
                        })
                        .OrderByDescending(g => g.ErrorCount)
                        .ToList();
                    result.AddRange(bySubType);
                    break;

                case "language":
                    var byLanguage = errors
                        .GroupBy(e => e.Language)
                        .Select(g => new ErrorGroup
                        {
                            GroupName = g.Key,
                            Description = $"Язык: {g.Key}",
                            ErrorCount = g.Count(),
                            Errors = g.ToList()
                        })
                        .OrderByDescending(g => g.ErrorCount)
                        .ToList();
                    result.AddRange(byLanguage);
                    break;

                case "typelanguage":
                    var byTypeAndLanguage = errors
                        .GroupBy(e => new { Type = e.ErrorType, Lang = e.Language })
                        .Select(g => new ErrorGroup
                        {
                            GroupName = $"{g.Key.Type} ({g.Key.Lang})",
                            Description = $"Ошибки {g.Key.Type} в {g.Key.Lang}",
                            ErrorCount = g.Count(),
                            Errors = g.ToList()
                        })
                        .OrderByDescending(g => g.ErrorCount)
                        .ToList();
                    result.AddRange(byTypeAndLanguage);
                    break;

                case "date":
                    var byDate = errors
                        .GroupBy(e => e.Timestamp.Date)
                        .Select(g => new ErrorGroup
                        {
                            GroupName = g.Key.ToShortDateString(),
                            Description = $"Ошибки от {g.Key.ToShortDateString()}",
                            ErrorCount = g.Count(),
                            Errors = g.ToList()
                        })
                        .OrderByDescending(g => DateTime.Parse(g.GroupName))  
                        .ToList();
                    result.AddRange(byDate);
                    break;

                default:
                    
                    var byPackage = errors
                        .GroupBy(e => e.PackageName)
                        .Select(g => new ErrorGroup
                        {
                            GroupName = g.Key,
                            Description = $"Пакет: {g.Key}",
                            ErrorCount = g.Count(),
                            Errors = g.ToList()
                        })
                        .OrderBy(g => g.GroupName)
                        .ToList();
                    result.AddRange(byPackage);
                    break;
            }

            return result;
        }
        public async Task<List<BuildError>> EnhanceErrorsWithAdvancedAnalysis(List<BuildError> errors)
        {
            var progressWindow = new Window
            {
                Title = "Анализ логов",
                Width = 400,
                Height = 100,
                WindowStartupLocation = WindowStartupLocation.CenterScreen,
                ResizeMode = ResizeMode.NoResize
            };

            var panel = new StackPanel { Margin = new Thickness(20) };
            panel.Children.Add(new TextBlock { Text = "Выполняется анализ логов ошибок...", Margin = new Thickness(0, 0, 0, 10) });
            var progressBar = new System.Windows.Controls.ProgressBar { IsIndeterminate = true, Height = 20 };
            panel.Children.Add(progressBar);

            progressWindow.Content = panel;
            progressWindow.Show();

            var tasks = new List<Task>();
            foreach (var error in errors)
            {
                tasks.Add(ErrorPatternAnalyzer.EnhanceErrorWithLogAnalysisAsync(error));

                if (tasks.Count >= 10)
                {
                    await Task.WhenAny(tasks);
                    tasks.RemoveAll(t => t.IsCompleted);
                }
            }

            await Task.WhenAll(tasks);

            progressWindow.Close();

            ErrorAnalysisStorage.AutoSaveAnalysisResults(errors);

            return errors;
        }
        private string GetErrorSubType(BuildError error)
        {
            if (error.ErrorType.Contains(":"))
            {
                var parts = error.ErrorType.Split(':');
                if (parts.Length > 1)
                    return parts[1].Trim();
            }

            string message = error.LogMessage.ToLower();

            if (message.Contains("test") || message.Contains("проверка"))
                return "Test";
            if (message.Contains("build") || message.Contains("сборка"))
                return "Build";
            if (message.Contains("configure") || message.Contains("конфигурация"))
                return "Configure";
            if (message.Contains("install") || message.Contains("установка"))
                return "Install";
            if (message.Contains("dependency") || message.Contains("зависимость"))
                return "Dependency";

            return error.ErrorType;
        }

        public List<BuildError> FilterErrors(List<BuildError> errors, string filterType = null, string filterValue = null)
        {
            if (string.IsNullOrEmpty(filterType) || string.IsNullOrEmpty(filterValue))
                return errors;

            switch (filterType.ToLower())
            {
                case "errortype":
                    return errors.Where(e => e.ErrorType.ToLower().Contains(filterValue.ToLower())).ToList();

                case "errorsubtype":
                    return errors.Where(e => e.ErrorSubType.ToLower().Contains(filterValue.ToLower())).ToList();

                case "language":
                    return errors.Where(e => e.Language.ToLower().Contains(filterValue.ToLower())).ToList();

                case "packagename":
                    return errors.Where(e => e.PackageName.ToLower().Contains(filterValue.ToLower())).ToList();

                case "logmessage":
                    return errors.Where(e => e.LogMessage.ToLower().Contains(filterValue.ToLower())).ToList();

                case "date":
                    if (DateTime.TryParse(filterValue, out DateTime date))
                        return errors.Where(e => e.Timestamp.Date == date.Date).ToList();
                    break;
            }

            return errors;
        }
        public async Task<List<BuildError>> FetchBuildErrorsAsync()
        {
            List<BuildError> errors = new List<BuildError>();

            try
            {
                var apiNotification = ShowNotification("Получение данных из FTBFS API...", "API");
                var ftbfsErrors = await GetErrorsFromFtbfsApiAsync();
                apiNotification.Close();

                if (ftbfsErrors.Count > 0)
                {
                    ShowTemporaryNotification($"Найдено {ftbfsErrors.Count} ошибок через FTBFS API", "Успех", 2);
                    errors.AddRange(ftbfsErrors);
                    return errors;
                }

                var logsNotification = ShowNotification("Поиск ошибок в логах сборки...", "Логи");
                var logErrors = await ScanBuildLogsForErrorsAsync();
                logsNotification.Close();

                if (logErrors.Count > 0)
                {
                    ShowTemporaryNotification($"Найдено {logErrors.Count} ошибок в логах сборки", "Успех", 2);
                    errors.AddRange(logErrors);
                    return errors;
                }

                var testDataNotification = ShowNotification("Загрузка тестовых данных...", "Тестовые данные");
                var testErrors = GetErrorsFromHardcodedData();
                testDataNotification.Close();

                if (testErrors.Count > 0)
                {
                    ShowTemporaryNotification($"Загружено {testErrors.Count} тестовых ошибок", "Успех", 2);
                    errors.AddRange(testErrors);
                    return errors;
                }

                ShowTemporaryNotification("Не удалось найти информацию о нерабочих пакетах ALT Linux. Возможно, все пакеты собираются успешно или структура сайтов изменилась.", "Результат", 5);
                return errors;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Произошла ошибка при поиске ошибок сборки:\n{ex.Message}", "Ошибка");
                return new List<BuildError>();
            }
        }

        private Window ShowNotification(string message, string title)
        {
            var window = new Window
            {
                Title = title,
                Content = new TextBlock
                {
                    Text = message,
                    HorizontalAlignment = HorizontalAlignment.Center,
                    VerticalAlignment = VerticalAlignment.Center,
                    TextWrapping = TextWrapping.Wrap
                },
                Width = 400,
                Height = 150,
                WindowStartupLocation = WindowStartupLocation.CenterScreen,
                ResizeMode = ResizeMode.NoResize,
                WindowStyle = WindowStyle.ToolWindow
            };
            window.Show();
            return window;
        }

        private void ShowTemporaryNotification(string message, string title, int seconds)
        {
            var window = ShowNotification(message, title);
            var timer = new System.Windows.Threading.DispatcherTimer
            {
                Interval = TimeSpan.FromSeconds(seconds)
            };
            timer.Tick += (s, e) =>
            {
                window.Close();
                timer.Stop();
            };
            timer.Start();
        }


        private async Task<List<BuildError>> GetErrorsFromFtbfsApiAsync()
        {
            List<BuildError> errors = new List<BuildError>();

            try
            {
                string ftbfsApiUrl = "https://rdb.altlinux.org/api/export/beehive/ftbfs";
                var apiNotification = ShowNotification("Получение данных об ошибках сборки...", "API");

                string response = await _httpClient.GetStringAsync(ftbfsApiUrl);
                apiNotification.Close();

                using (JsonDocument document = JsonDocument.Parse(response))
                {
                    JsonElement root = document.RootElement;

                    if (root.TryGetProperty("ftbfs", out var ftbfsArray))
                    {
                        int count = ftbfsArray.GetArrayLength();
                        ShowTemporaryNotification($"Найдено {count} пакетов с ошибками сборки", "Информация", 2);

                        HashSet<string> processedPackages = new HashSet<string>();

                        foreach (var item in ftbfsArray.EnumerateArray())
                        {
                            try
                            {
                                if (!item.TryGetProperty("name", out var nameProperty))
                                    continue;

                                string packageName = nameProperty.GetString();

                                if (packageName.ToLower().Contains("driver") ||
                                    packageName.ToLower().Contains("firmware"))
                                    continue;

                                string packageKey = packageName;
                                if (item.TryGetProperty("arch", out var archProperty))
                                    packageKey += "-" + archProperty.GetString();

                                if (processedPackages.Contains(packageKey))
                                    continue;

                                processedPackages.Add(packageKey);

                                string url = "";
                                if (item.TryGetProperty("url", out var urlProperty))
                                    url = urlProperty.GetString();

                                DateTime ftbfsDate = DateTime.Now;
                                if (item.TryGetProperty("ftbfs_since", out var dateProperty))
                                {
                                    string dateStr = dateProperty.GetString();
                                    if (DateTime.TryParse(dateStr, out DateTime parsedDate))
                                        ftbfsDate = parsedDate;
                                }

                                string arch = "unknown";
                                if (item.TryGetProperty("arch", out archProperty))
                                    arch = archProperty.GetString();

                                string version = "";
                                if (item.TryGetProperty("version", out var verProperty))
                                    version = verProperty.GetString();

                                string release = "";
                                if (item.TryGetProperty("release", out var relProperty))
                                    release = relProperty.GetString();

                                string errorMsg = $"Ошибка сборки пакета {packageName}";
                                if (!string.IsNullOrEmpty(version))
                                    errorMsg += $" версии {version}";
                                if (!string.IsNullOrEmpty(release))
                                    errorMsg += $"-{release}";
                                errorMsg += $" для архитектуры {arch}";

                                errors.Add(new BuildError
                                {
                                    PackageName = packageName,
                                    ErrorType = "Build Failed",
                                    LogMessage = errorMsg,
                                    Timestamp = ftbfsDate,
                                    Language = DetectLanguageFromPackageName(packageName),
                                    SuggestedFix = "Требуется анализ логов сборки",
                                    LogUrl = url
                                });

                                if (errors.Count >= 10)
                                    break;
                            }
                            catch (Exception)
                            {
                                continue;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при получении данных из API: {ex.Message}", "Ошибка");
            }

            errors = errors.OrderBy(e => e.PackageName).ToList();

            return errors;
        }

        private string DetectLanguageFromPackageName(string packageName)
        {
            string packageNameLower = packageName.ToLower();

            if (packageNameLower.StartsWith("perl-"))
                return "Perl";
            if (packageNameLower.StartsWith("python"))
                return "Python";
            if (packageNameLower.Contains("java") || packageNameLower.Contains("jpp"))
                return "Java";
            if (packageNameLower.StartsWith("ruby"))
                return "Ruby";
            if (packageNameLower.StartsWith("rust-") || packageNameLower.Contains("rust"))
                return "Rust";
            if (packageNameLower.StartsWith("golang-") || packageNameLower.StartsWith("go-"))
                return "Go";
            if (packageNameLower.Contains("php"))
                return "PHP";
            if (packageNameLower.Contains("gcc") || packageNameLower.Contains("g++") || packageNameLower.Contains("clang"))
                return "C/C++";
            if (packageNameLower.Contains("node") || packageNameLower.Contains("js-"))
                return "JavaScript";
            if (packageNameLower.Contains("cmake"))
                return "CMake";
            if (packageNameLower.Contains("meson"))
                return "Meson";

            return "Unknown";
        }
        private List<BuildError> ParseFtbfsJsonData(string jsonData)
        {
            List<BuildError> errors = new List<BuildError>();

            try
            {
                using (JsonDocument document = JsonDocument.Parse(jsonData))
                {
                    JsonElement root = document.RootElement;

                    if (root.TryGetProperty("ftbfs", out var ftbfsArray))
                    {
                        foreach (var item in ftbfsArray.EnumerateArray())
                        {
                            try
                            {
                                string packageName = item.GetProperty("name").GetString();
                                string arch = item.GetProperty("arch").GetString();
                                string url = item.GetProperty("url").GetString();
                                string version = item.GetProperty("version").GetString();
                                string release = item.GetProperty("release").GetString();

                                DateTime ftbfsDate = DateTime.Now;
                                if (item.TryGetProperty("ftbfs_since", out var dateProperty))
                                {
                                    string dateStr = dateProperty.GetString();
                                    if (DateTime.TryParse(dateStr, out DateTime parsedDate))
                                    {
                                        ftbfsDate = parsedDate;
                                    }
                                }

                                errors.Add(new BuildError
                                {
                                    PackageName = packageName,
                                    ErrorType = "Build Failed",
                                    LogMessage = $"Ошибка сборки пакета {packageName} версии {version}-{release} для архитектуры {arch}",
                                    Timestamp = ftbfsDate,
                                    Language = DetectLanguageFromPackageName(packageName),
                                    SuggestedFix = "Требуется анализ логов сборки",
                                    LogUrl = url
                                });
                            }
                            catch
                            {
                                continue;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при разборе данных JSON: {ex.Message}", "Ошибка");
            }

            return errors;
        }
        private string GetInitialErrorType(string url, string packageName)
        {
            if (url.Contains("/error/"))
            {
                if (url.Contains("configure."))
                    return "Configure Error";
                if (url.Contains("makeinstall."))
                    return "Install Error";
                if (url.Contains("cmake"))
                    return "CMake Error";
                if (url.Contains("make."))
                    return "Build Error";
                if (url.Contains("buildreq."))
                    return "Dependency Error";
                if (url.Contains("check."))
                    return "Test Error";
                if (url.Contains("rpmlint."))
                    return "RPM Lint Error";
            }

            string packageNameLower = packageName.ToLower();

            if (packageNameLower.StartsWith("perl-"))
                return "Perl Module Error";
            if (packageNameLower.StartsWith("python"))
                return "Python Build Error";
            if (packageNameLower.Contains("java") || packageNameLower.Contains("jpp"))
                return "Java Build Error";
            if (packageNameLower.StartsWith("ruby"))
                return "Ruby Build Error";
            if (packageNameLower.StartsWith("rust-") || packageNameLower.Contains("rust"))
                return "Rust Build Error";
            if (packageNameLower.StartsWith("golang") || packageNameLower.StartsWith("go-"))
                return "Go Build Error";
            if (packageNameLower.Contains("php"))
                return "PHP Build Error";
            if (packageNameLower.Contains("gcc") || packageNameLower.Contains("g++") || packageNameLower.Contains("clang"))
                return "Compiler Error";
            if (packageNameLower.Contains("test"))
                return "Test Error";
            if (packageNameLower.Contains("docker") || packageNameLower.Contains("container"))
                return "Container Build Error";
            if (packageNameLower.Contains("cmake"))
                return "CMake Error";
            if (packageNameLower.Contains("meson"))
                return "Meson Build Error";

            return "Build Failed";
        }
        private string GetInitialSuggestedFix(string errorType, string language)
        {
            switch (errorType)
            {
                case "Configure Error":
                    return "Проверьте параметры конфигурации и зависимости сборки";
                case "CMake Error":
                    return "Проверьте CMakeLists.txt на наличие ошибок и зависимости";
                case "Build Error":
                    return "Проверьте исходный код на наличие ошибок компиляции";
                case "Dependency Error":
                    return "Проверьте доступность всех необходимых зависимостей";
                case "Test Error":
                    return "Тесты пакета не проходят, проверьте логи тестирования";
                case "RPM Lint Error":
                    return "Проверьте соответствие пакета правилам RPM";
                case "Install Error":
                    return "Проверьте этап установки в spec-файле";
                case "Perl Module Error":
                    return "Проверьте соответствие требованиям Perl и зависимости";
                case "Python Build Error":
                    return "Проверьте соответствие требованиям Python и зависимости";
                case "Java Build Error":
                    return "Проверьте соответствие версии Java и зависимости";
                case "Ruby Build Error":
                    return "Проверьте соответствие требованиям Ruby и зависимости";
                case "Rust Build Error":
                    return "Проверьте Cargo.toml и зависимости Rust";
                case "Go Build Error":
                    return "Проверьте go.mod и зависимости Go";
                case "Container Build Error":
                    return "Проверьте настройки контейнеризации";
                case "Compiler Error":
                    return "Проверьте совместимость с используемым компилятором";
                case "Meson Build Error":
                    return "Проверьте meson.build на наличие ошибок";
                default:
                    if (language != "Unknown")
                        return $"Требуется анализ логов сборки ({language})";
                    else
                        return "Требуется анализ логов сборки";
            }
        }

        private List<BuildError> GetErrorsFromHardcodedData()
        {
            try
            {
                string jsonFilePath = "ftbfs_data.json";

                if (!System.IO.File.Exists(jsonFilePath))
                {
                    MessageBox.Show($"Файл с данными не найден: {jsonFilePath}", "Предупреждение");
                    return new List<BuildError>();
                }

                string jsonData = System.IO.File.ReadAllText(jsonFilePath);

                return ParseFtbfsJsonData(jsonData);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при чтении файла с данными: {ex.Message}", "Ошибка");
                return new List<BuildError>();
            }
        }

        public void CreateTestDataFile()
        {
            try
            {
                string jsonFilePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "ftbfs_data.json");

                
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при создании тестового файла: {ex.Message}", "Ошибка");
            }
        }


        private async Task<List<BuildError>> ScanBuildLogsForErrorsAsync()
        {
            List<BuildError> errors = new List<BuildError>();

            try
            {
                var logsPage = await _httpClient.GetStringAsync(LogsUrl);

                var doc = new HtmlDocument();
                doc.LoadHtml(logsPage);

                var packageLinks = doc.DocumentNode.SelectNodes("//a[@href]");

                if (packageLinks != null && packageLinks.Count > 0)
                {
                    var packageDirs = packageLinks
                        .Select(link => link.GetAttributeValue("href", ""))
                        .Where(href => href.EndsWith("/") &&
                               !href.Contains("..") &&
                               !href.Equals("./") &&
                               !href.Equals("../") &&
                               !href.ToLower().Contains("driver") && 
                               !href.ToLower().Contains("firmware")) 
                        .ToList();

                    MessageBox.Show($"Найдено {packageDirs.Count} директорий пакетов", "Логи");

                    int packagesToCheck = Math.Min(50, packageDirs.Count);

                    for (int i = 0; i < packagesToCheck; i++)
                    {
                        string packageDir = packageDirs[i];
                        string packageName = packageDir.TrimEnd('/');

                        try
                        {
                            string packageUrl = $"{LogsUrl}{packageDir}";
                            var packagePage = await _httpClient.GetStringAsync(packageUrl);

                            var packageDoc = new HtmlDocument();
                            packageDoc.LoadHtml(packagePage);

                            var subdirs = packageDoc.DocumentNode
                                .SelectNodes("//a[@href]")
                                ?.Select(link => link.GetAttributeValue("href", ""))
                                ?.Where(href => href.EndsWith("/") &&
                                       !href.Equals("./") &&
                                       !href.Equals("../"))
                                ?.ToList();

                            if (subdirs != null && subdirs.Count > 0)
                            {
                                foreach (var subdir in subdirs)
                                {
                                    string subdirUrl = $"{packageUrl}{subdir}";
                                    var subdirPage = await _httpClient.GetStringAsync(subdirUrl);

                                    var subdirDoc = new HtmlDocument();
                                    subdirDoc.LoadHtml(subdirPage);

                                    var logFiles = subdirDoc.DocumentNode
                                        .SelectNodes("//a[@href]")
                                        ?.Select(link => link.GetAttributeValue("href", ""))
                                        ?.Where(href => href.EndsWith(".log") ||
                                               href.Contains("error") ||
                                               href.Contains("failed"))
                                        ?.ToList();

                                    if (logFiles != null && logFiles.Count > 0)
                                    {
                                        string errorLogFile = logFiles
                                            .FirstOrDefault(f => f.Contains("error") || f.Contains("failed")) ??
                                            logFiles.Last(); 

                                        string logUrl = $"{subdirUrl}{errorLogFile}";

                                        errors.Add(new BuildError
                                        {
                                            PackageName = packageName,
                                            ErrorType = "Build Failed",
                                            LogMessage = $"Ошибка сборки в директории {subdir.TrimEnd('/')}",
                                            Timestamp = DateTime.Now,
                                            Language = DetectLanguageFromPackageName(packageName),
                                            SuggestedFix = "Требуется анализ логов сборки",
                                            LogUrl = logUrl
                                        });

                                        break;
                                    }
                                }
                            }
                            else
                            {
                                var logFiles = packageDoc.DocumentNode
                                    .SelectNodes("//a[@href]")
                                    ?.Select(link => link.GetAttributeValue("href", ""))
                                    ?.Where(href => href.EndsWith(".log") ||
                                           href.Contains("error") ||
                                           href.Contains("failed"))
                                    ?.ToList();

                                if (logFiles != null && logFiles.Count > 0)
                                {
                                    string errorLogFile = logFiles
                                        .FirstOrDefault(f => f.Contains("error") || f.Contains("failed")) ??
                                        logFiles.Last(); 

                                    string logUrl = $"{packageUrl}{errorLogFile}";

                                   
                                    errors.Add(new BuildError
                                    {
                                        PackageName = packageName,
                                        ErrorType = "Build Failed",
                                        LogMessage = "Ошибка сборки",
                                        Timestamp = DateTime.Now,
                                        Language = DetectLanguageFromPackageName(packageName),
                                        SuggestedFix = "Требуется анализ логов сборки",
                                        LogUrl = logUrl
                                    });
                                }
                            }
                        }
                        catch (Exception)
                        {
                            continue;
                        }

                        if (errors.Count >= 30)
                            break;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сканировании логов сборки: {ex.Message}", "Ошибка");
            }
            return new List<BuildError>();
            return errors;
        }

        private async Task<List<BuildError>> ScanPackagesPageForErrorsAsync()
        {
            List<BuildError> errors = new List<BuildError>();

            try
            {
                var packagesPage = await _httpClient.GetStringAsync(PackagesUrl);

                var doc = new HtmlDocument();
                doc.LoadHtml(packagesPage);

                var packageLinks = doc.DocumentNode.SelectNodes("//a[@href]");

                if (packageLinks != null && packageLinks.Count > 0)
                {
                    var packageHrefs = packageLinks
                        .Select(link => new {
                            Href = link.GetAttributeValue("href", ""),
                            Text = link.InnerText.Trim()
                        })
                        .Where(p => !string.IsNullOrEmpty(p.Text) &&
                                   (p.Href.Contains("/srpms/") || p.Href.Contains("/packages/")))
                        .ToList();

                    MessageBox.Show($"Найдено {packageHrefs.Count} ссылок на пакеты", "Пакеты");

                    int packagesToCheck = Math.Min(20, packageHrefs.Count);

                    for (int i = 0; i < packagesToCheck; i++)
                    {
                        var package = packageHrefs[i];

                        try
                        {
                            string packageUrl = package.Href.StartsWith("http") ?
                                                package.Href :
                                                $"{PackagesUrl.TrimEnd('/')}{package.Href}";

                            var packagePage = await _httpClient.GetStringAsync(packageUrl);

                            var packageDoc = new HtmlDocument();
                            packageDoc.LoadHtml(packagePage);

                            var errorIndicators = packageDoc.DocumentNode.SelectNodes(
                                "//div[contains(@class, 'alert-danger')] | " +
                                "//div[contains(@class, 'error')] | " +
                                "//span[contains(@class, 'failed')] | " +
                                "//span[contains(text(), 'ошибка')] | " +
                                "//span[contains(text(), 'Ошибка')]");

                            if (errorIndicators != null && errorIndicators.Count > 0)
                            {
                                string errorText = errorIndicators.First().InnerText.Trim();

                                errors.Add(new BuildError
                                {
                                    PackageName = package.Text,
                                    ErrorType = DetermineErrorTypeFromText(errorText),
                                    LogMessage = errorText,
                                    Timestamp = DateTime.Now,
                                    Language = DetermineLanguage("", package.Text),
                                    SuggestedFix = SuggestFix(errorText),
                                    LogUrl = $"{LogsUrl}{package.Text}/"
                                });

                                if (errors.Count >= 15)
                                {
                                    break;
                                }
                            }
                        }
                        catch (Exception)
                        {
                            continue;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сканировании страницы пакетов: {ex.Message}", "Ошибка");
            }

            return errors;
        }

        private bool ContainsBuildErrors(string logContent)
        {
            if (string.IsNullOrEmpty(logContent))
                return false;

            string[] errorMarkers = {
                "BUILD FAILED", "build failed", "Error", "ERROR", "Failed", "FAILED",
                "ошибка", "ОШИБКА", "сбой", "не удалось", "ПРОВАЛ",
                "make: *** [", "error:", "Makefile:", "configure: error",
                "E: build failed", "Segmentation fault", "Aborted"
            };

            foreach (var marker in errorMarkers)
            {
                if (logContent.Contains(marker))
                {
                    return true;
                }
            }

            return false;
        }

        private string ExtractErrorMessage(string logContent)
        {
            if (string.IsNullOrEmpty(logContent))
                return "Не удалось получить сообщение об ошибке";

            var errorMatch = Regex.Match(logContent, @"(?:error:|ERROR:|FAILED:|make\[\d+\]: \*\*\* |configure: error:|ошибка:|ОШИБКА:).*");
            if (errorMatch.Success)
            {
                return errorMatch.Value.Trim();
            }

            foreach (var line in logContent.Split('\n'))
            {
                if (line.Contains("error") || line.Contains("ошибка") || line.Contains("failed") || line.Contains("FAILED"))
                {
                    return line.Trim();
                }
            }

            return "Не удалось извлечь сообщение об ошибке из лога";
        }
        private string DetermineErrorTypeFromUrl(string url, string packageName)
{
    if (logAnalysisCache.ContainsKey(url))
        return logAnalysisCache[url];
        if (url.Contains("/error/"))
    {
        if (url.Contains("configure."))
            return "Configure Error";
        if (url.Contains("makeinstall."))
            return "Install Error";
        if (url.Contains("cmake"))
            return "CMake Error";
        if (url.Contains("make."))
            return "Make Error";
        if (url.Contains("buildreq."))
            return "Build Requirements Error";
        if (url.Contains("check."))
            return "Test Error";
        if (url.Contains("rpmlint."))
            return "RPM Lint Error";
    }
    
    string packageNameLower = packageName.ToLower();
    
    if (packageNameLower.Contains("python"))
        return "Python Build Error";
    if (packageNameLower.Contains("java") || packageNameLower.Contains("jpp"))
        return "Java Build Error";
    if (packageNameLower.Contains("perl"))
        return "Perl Build Error";
    if (packageNameLower.Contains("ruby"))
        return "Ruby Build Error";
    if (packageNameLower.Contains("rust"))
        return "Rust Build Error";
    if (packageNameLower.Contains("gcc") || packageNameLower.Contains("g++") || packageNameLower.Contains("clang"))
        return "Compiler Error";
    if (packageNameLower.Contains("test"))
        return "Test Error";
    if (packageNameLower.Contains("docker") || packageNameLower.Contains("container"))
        return "Container Build Error";
    if (packageNameLower.Contains("cmake"))
        return "CMake Error";
    if (packageNameLower.Contains("meson"))
        return "Meson Build Error";
    
    ThreadPool.QueueUserWorkItem(async state =>
    {
        try
        {
            using (HttpClient client = new HttpClient())
            {
                client.Timeout = TimeSpan.FromSeconds(5); 
                var logContent = await client.GetStringAsync(url);
                
               
                string errorType = AnalyzeLogContent(logContent);
                
                if (!string.IsNullOrEmpty(errorType))
                {
                    lock (logAnalysisCache)
                    {
                        logAnalysisCache[url] = errorType;
                    }
                }
            }
        }
        catch
        {
        }
    });
    
    return "Build Failed";
}
        private string AnalyzeLogContent(string logContent)
        {
            if (string.IsNullOrEmpty(logContent))
                return "Build Failed";

            string logLower = logContent.ToLower();

            if (logLower.Contains("configure: error") || logLower.Contains("error: configure failed"))
                return "Configure Error";

            if (logLower.Contains("cmake error") || logLower.Contains("cmakeerror"))
                return "CMake Error";

            if (logLower.Contains("make: *** [makefile") || logLower.Contains("make[") ||
                logLower.Contains("error: make failed"))
                return "Make Error";

            if (logLower.Contains("undefined reference to") || logLower.Contains("undefined symbol"))
                return "Linker Error";

            if (logLower.Contains("no such file or directory") || logLower.Contains("cannot find"))
                return "Missing File Error";

            if (logLower.Contains("testing") && (logLower.Contains("failed") || logLower.Contains("error")))
                return "Test Error";

            if (logLower.Contains("syntax error") || logLower.Contains("parse error"))
                return "Syntax Error";

            if (logLower.Contains("permission denied"))
                return "Permission Error";

            if (logLower.Contains("out of memory") || logLower.Contains("memory exhausted") ||
                logLower.Contains("killed") || logLower.Contains("exit code 137"))
                return "Memory Error";

            if (logLower.Contains("timeout") || logLower.Contains("timed out"))
                return "Timeout Error";

            if (logLower.Contains("requires") && logLower.Contains("not found"))
                return "Dependency Error";

            if (logLower.Contains("rpmlint"))
                return "RPM Lint Error";

            if (logLower.Contains("install") &&
                (logLower.Contains("failed") || logLower.Contains("error")))
                return "Install Error";

            if (logLower.Contains("patch") &&
                (logLower.Contains("failed") || logLower.Contains("error")))
                return "Patch Error";

            return "Build Failed";
        }

        private string SuggestFixBasedOnErrorType(string errorType, string language, string packageName)
        {
            switch (errorType)
            {
                case "Configure Error":
                    return "Проверьте параметры конфигурации и зависимости сборки";

                case "CMake Error":
                    return "Проверьте CMakeLists.txt на наличие ошибок и зависимости";

                case "Make Error":
                    return "Проверьте исходный код на наличие ошибок компиляции";

                case "Linker Error":
                    return "Проверьте правильность подключения библиотек";

                case "Missing File Error":
                    return "Проверьте наличие всех необходимых файлов и путей";

                case "Test Error":
                    return "Тесты пакета не проходят, проверьте логи тестирования";

                case "Syntax Error":
                    return "Исправьте синтаксические ошибки в исходном коде";

                case "Permission Error":
                    return "Проверьте права доступа к файлам и директориям";

                case "Memory Error":
                    return "Процесс сборки требует больше памяти, чем доступно";

                case "Timeout Error":
                    return "Процесс сборки занимает слишком много времени";

                case "Dependency Error":
                    return "Проверьте доступность всех необходимых зависимостей";

                case "RPM Lint Error":
                    return "Проверьте соответствие пакета правилам RPM";

                case "Install Error":
                    return "Проверьте этап установки в spec-файле";

                case "Patch Error":
                    return "Проверьте применяемые патчи на актуальность";

                case "Python Build Error":
                    return "Проверьте соответствие требованиям Python и зависимости";

                case "Java Build Error":
                    return "Проверьте соответствие версии Java и зависимости";

                case "Perl Build Error":
                    return "Проверьте соответствие требованиям Perl и зависимости";

                case "Ruby Build Error":
                    return "Проверьте соответствие требованиям Ruby и зависимости";

                case "Rust Build Error":
                    return "Проверьте Cargo.toml и зависимости Rust";

                case "Container Build Error":
                    return "Проверьте настройки контейнеризации";

                case "Compiler Error":
                    return "Проверьте совместимость с используемым компилятором";

                case "Meson Build Error":
                    return "Проверьте meson.build на наличие ошибок";

                default:
                    if (language != "Unknown")
                        return $"Требуется анализ логов сборки ({language})";
                    else
                        return "Требуется анализ логов сборки";
            }
        }
        private string DetermineErrorType(string logContent)
        {
            if (string.IsNullOrEmpty(logContent))
                return "Unknown Error";

            if (logContent.Contains("CMake Error"))
                return "CMake Error";
            if (logContent.Contains("configure: error"))
                return "Configure Error";
            if (logContent.Contains("error:") && (logContent.Contains("compil") || logContent.Contains("компил")))
                return "Compilation Error";
            if (logContent.Contains("ImportError") || logContent.Contains("ModuleNotFoundError") ||
                logContent.Contains("dependency") || logContent.Contains("зависимост"))
                return "Dependency Error";
            if (logContent.Contains("No such file") || logContent.Contains("не найден") ||
                logContent.Contains("not found") || logContent.Contains("cannot find"))
                return "Missing File";
            if (logContent.Contains("test") && (logContent.Contains("failed") || logContent.Contains("не пройден")))
                return "Test Failed";

            return "Build Error";
        }

        private string DetermineErrorTypeFromText(string errorText)
        {
            if (string.IsNullOrEmpty(errorText))
                return "Unknown Error";

            if (errorText.Contains("build failed") || errorText.Contains("сборка не удалась"))
                return "Build Failed";
            if (errorText.Contains("compile") || errorText.Contains("compilation") || errorText.Contains("компиляц"))
                return "Compilation Error";
            if (errorText.Contains("dependency") || errorText.Contains("requires") || errorText.Contains("зависимост"))
                return "Dependency Error";
            if (errorText.Contains("not found") || errorText.Contains("missing") || errorText.Contains("не найден"))
                return "Missing File";
            if (errorText.Contains("test") || errorText.Contains("тест"))
                return "Test Failed";

            return "Build Error";
        }

        private string DetermineLanguage(string content, string packageName)
        {
            if (!string.IsNullOrEmpty(content))
            {
                if (content.Contains("gcc") || content.Contains("g++") || content.Contains("clang") ||
                    content.Contains("make") || content.Contains("cmake"))
                    return "C/C++";
                if (content.Contains("python") || content.Contains("pip") || content.Contains("setuptools"))
                    return "Python";
                if (content.Contains("java") || content.Contains("javac") || content.Contains("maven"))
                    return "Java";
                if (content.Contains("node") || content.Contains("npm") || content.Contains("yarn"))
                    return "JavaScript";
                if (content.Contains("go build") || content.Contains("go test") || content.Contains("golang"))
                    return "Go";
                if (content.Contains("cargo") || content.Contains("rustc") || content.Contains("rust"))
                    return "Rust";
                if (content.Contains("perl") || content.Contains("cpan"))
                    return "Perl";
                if (content.Contains("ruby") || content.Contains("gem") || content.Contains("rake"))
                    return "Ruby";
                if (content.Contains("zig"))
                    return "Zig";
            }

            packageName = packageName.ToLower();

            if (packageName.Contains("python") || packageName.StartsWith("py") || packageName.StartsWith("python"))
                return "Python";
            if (packageName.Contains("java") || packageName.Contains("openjdk") || packageName.Contains("maven"))
                return "Java";
            if (packageName.Contains("node") || packageName.Contains("npm") || packageName.Contains("js"))
                return "JavaScript";
            if (packageName.Contains("golang") || packageName.StartsWith("go-"))
                return "Go";
            if (packageName.Contains("rust") || packageName.StartsWith("rust"))
                return "Rust";
            if (packageName.Contains("perl") || packageName.StartsWith("perl"))
                return "Perl";
            if (packageName.Contains("ruby") || packageName.StartsWith("ruby"))
                return "Ruby";
            if (packageName.Contains("zig"))
                return "Zig";
            if (packageName.Contains("gcc") || packageName.Contains("g++") || packageName.Contains("clang") ||
                packageName.Contains("cpp") || packageName.Contains("c++") || packageName.Contains("libstdc++"))
                return "C/C++";

            return "Unknown";
        }
        public class LogAnalyzer
        {
            private static readonly HttpClient _httpClient;
            private static readonly Dictionary<string, LogAnalysisResult> _cache;

            static LogAnalyzer()
            {
                _httpClient = new HttpClient();
                _httpClient.Timeout = TimeSpan.FromSeconds(15);
                _cache = new Dictionary<string, LogAnalysisResult>();
            }

            public static async Task<LogAnalysisResult> AnalyzeLogAsync(string url)
            {
                if (_cache.ContainsKey(url))
                    return _cache[url];

                try
                {
                    string logContent = await _httpClient.GetStringAsync(url);

                    var result = AnalyzeLogContent(logContent, url);

                    lock (_cache)
                    {
                        if (!_cache.ContainsKey(url))
                            _cache[url] = result;
                    }

                    return result;
                }
                catch (Exception ex)
                {
                    return new LogAnalysisResult
                    {
                        ErrorType = "Build Failed",
                        ErrorSubType = "Unknown",
                        ErrorDetails = $"Ошибка при загрузке лога: {ex.Message}",
                        SuggestedFix = "Требуется ручной анализ логов"
                    };
                }
            }

            public static LogAnalysisResult AnalyzeLog(string url)
            {
                return AnalyzeLogAsync(url).GetAwaiter().GetResult();
            }

            public static void TryAnalyzeLogAsync(string url, Action<LogAnalysisResult> callback)
            {
                if (_cache.ContainsKey(url))
                {
                    callback(_cache[url]);
                    return;
                }

                Task.Run(async () =>
                {
                    try
                    {
                        var result = await AnalyzeLogAsync(url);
                        callback(result);
                    }
                    catch
                    {
                    }
                });
            }

            private static LogAnalysisResult AnalyzeLogContent(string logContent, string url)
            {
                var result = new LogAnalysisResult
                {
                    RawLog = logContent,
                    LogUrl = url
                };

                if (string.IsNullOrEmpty(logContent))
                {
                    result.ErrorType = "Empty Log";
                    result.ErrorSubType = "Empty Log";
                    result.ErrorDetails = "Лог пустой или недоступен";
                    result.SuggestedFix = "Проверьте доступность лога по URL";
                    return result;
                }

                string logLower = logContent.ToLower();

                result.Language = DetectLanguageFromLog(logContent, url);

                result.ErrorDetails = ExtractErrorDetails(logContent);

                if (logLower.Contains("test summary report") ||
                    logLower.Contains("failed test") ||
                    logLower.Contains("subtests failed") ||
                    logLower.Contains("%check"))
                {
                    result.ErrorType = "Test Error";

                    if (logLower.Contains("expects") || logLower.Contains("expected") ||
                        logLower.Contains("doesn't match") || logLower.Contains("not equal"))
                        result.ErrorSubType = "Test Assertion Failed";
                    else if (logLower.Contains("timeout") || logLower.Contains("timed out"))
                        result.ErrorSubType = "Test Timeout";
                    else if (logLower.Contains("memory") || logLower.Contains("allocation failed"))
                        result.ErrorSubType = "Test Memory Error";
                    else
                        result.ErrorSubType = "Test Execution Failed";

                    result.SuggestedFix = "Проверьте тесты пакета, возможно требуется обновление тестовых данных или изменение логики тестов";
                }
                else if (logLower.Contains("rpm build errors") || logLower.Contains("bad exit status"))
                {
                    result.ErrorType = "RPM Process Error";

                    if (logLower.Contains("%check"))
                        result.ErrorSubType = "RPM Check Failed";
                    else if (logLower.Contains("%install"))
                        result.ErrorSubType = "RPM Install Failed";
                    else if (logLower.Contains("%build"))
                        result.ErrorSubType = "RPM Build Failed";
                    else if (logLower.Contains("%prep"))
                        result.ErrorSubType = "RPM Prep Failed";
                    else
                        result.ErrorSubType = "RPM Packaging Failed";

                    result.SuggestedFix = "Проверьте spec-файл и соответствующие скрипты сборки";
                }
                else if (logLower.Contains("configure: error") || logLower.Contains("configuration failed"))
                {
                    result.ErrorType = "Configure Error";

                    if (logLower.Contains("missing") || logLower.Contains("not found"))
                        result.ErrorSubType = "Missing Dependency";
                    else if (logLower.Contains("version") || logLower.Contains("incompatible"))
                        result.ErrorSubType = "Version Incompatibility";
                    else if (logLower.Contains("compiler") || logLower.Contains("compilation"))
                        result.ErrorSubType = "Compiler Error";
                    else
                        result.ErrorSubType = "Configuration Failed";

                    result.SuggestedFix = "Проверьте параметры конфигурации и зависимости пакета";
                }
                else if (logLower.Contains("make: ***") || (logLower.Contains("error") && logLower.Contains("make")))
                {
                    result.ErrorType = "Build Error";

                    if (logLower.Contains("undefined reference") || logLower.Contains("undefined symbol"))
                        result.ErrorSubType = "Linker Error";
                    else if (logLower.Contains("syntax error") || logLower.Contains(": error:"))
                        result.ErrorSubType = "Compilation Error";
                    else if (logLower.Contains("memory") || logLower.Contains("allocation failed"))
                        result.ErrorSubType = "Memory Error";
                    else
                        result.ErrorSubType = "Make Failed";

                    result.SuggestedFix = "Проверьте исходный код на наличие ошибок компиляции или проблем с зависимостями";
                }
                else if (logLower.Contains("install failed") || logLower.Contains("cannot install"))
                {
                    result.ErrorType = "Install Error";

                    if (logLower.Contains("permission denied") || logLower.Contains("access denied"))
                        result.ErrorSubType = "Permission Error";
                    else if (logLower.Contains("file exists") || logLower.Contains("already exists"))
                        result.ErrorSubType = "File Conflict";
                    else if (logLower.Contains("missing") || logLower.Contains("not found"))
                        result.ErrorSubType = "Missing File";
                    else
                        result.ErrorSubType = "Installation Failed";

                    result.SuggestedFix = "Проверьте установочные скрипты и наличие всех необходимых файлов";
                }
                else
                {
                    if (logLower.Contains("undefined value") || logLower.Contains("can't use an undefined value"))
                    {
                        result.ErrorType = "Undefined Value Error";
                        result.ErrorSubType = "Null Reference";
                        result.SuggestedFix = "Проверьте код на использование необъявленных или NULL переменных";
                    }
                    else if (logLower.Contains("dependency") || logLower.Contains("requires") ||
                            logLower.Contains("not found") || logLower.Contains("missing"))
                    {
                        result.ErrorType = "Dependency Error";
                        result.ErrorSubType = "Missing Dependency";
                        result.SuggestedFix = "Убедитесь, что все требуемые зависимости доступны и имеют правильные версии";
                    }
                    else if (logLower.Contains("syntax error") || logLower.Contains("parse error"))
                    {
                        result.ErrorType = "Syntax Error";
                        result.ErrorSubType = "Invalid Syntax";
                        result.SuggestedFix = "Исправьте синтаксические ошибки в коде";
                    }
                    else if (logLower.Contains("type error") || logLower.Contains("wrong type") ||
                            logLower.Contains("expected type"))
                    {
                        result.ErrorType = "Type Error";
                        result.ErrorSubType = "Type Mismatch";
                        result.SuggestedFix = "Проверьте соответствие типов данных";
                    }
                    else if (logLower.Contains("cannot import") || logLower.Contains("require") ||
                            logLower.Contains("import failed"))
                    {
                        result.ErrorType = "Import/Require Error";
                        result.ErrorSubType = "Module Not Found";
                        result.SuggestedFix = "Убедитесь, что все требуемые модули установлены и доступны";
                    }
                    else if (logLower.Contains("undefined symbol") || logLower.Contains("undefined reference"))
                    {
                        result.ErrorType = "Linker Error";
                        result.ErrorSubType = "Symbol Not Found";
                        result.SuggestedFix = "Проверьте правильность подключения библиотек и объявления символов";
                    }
                    else if (logLower.Contains("yaml") || logLower.Contains("yml"))
                    {
                        result.ErrorType = "YAML Error";
                        result.ErrorSubType = "YAML Parsing Failed";
                        result.SuggestedFix = "Проверьте синтаксис YAML-файлов";
                    }
                    else if (logLower.Contains("regex") || logLower.Contains("doesn't match"))
                    {
                        result.ErrorType = "Regex Error";
                        result.ErrorSubType = "Regex Pattern Failed";
                        result.SuggestedFix = "Проверьте регулярные выражения на корректность";
                    }
                    else
                    {
                        result.ErrorType = "Build Failed";
                        result.ErrorSubType = "Unknown Error";
                        result.SuggestedFix = "Требуется ручной анализ логов";
                    }
                }

                RefineErrorBasedOnLanguage(result);

                return result;
            }

            private static string DetectLanguageFromLog(string logContent, string url)
            {
                string logLower = logContent.ToLower();
                string urlLower = url.ToLower();

                if (urlLower.Contains("perl-"))
                    return "Perl";
                if (urlLower.Contains("python"))
                    return "Python";
                if (urlLower.Contains("java-") || urlLower.Contains("-jpp"))
                    return "Java";
                if (urlLower.Contains("ruby"))
                    return "Ruby";
                if (urlLower.Contains("rust-"))
                    return "Rust";
                if (urlLower.Contains("golang-") || urlLower.Contains("go-"))
                    return "Go";
                if (urlLower.Contains("php"))
                    return "PHP";
                if (urlLower.Contains("node-") || urlLower.Contains("js-"))
                    return "JavaScript";

                if (logLower.Contains(".pm") || logLower.Contains("perl") || logLower.Contains("cpan"))
                    return "Perl";
                if (logLower.Contains("python") || logLower.Contains(".py") || logLower.Contains("pip"))
                    return "Python";
                if (logLower.Contains("java") || logLower.Contains(".jar") || logLower.Contains("maven"))
                    return "Java";
                if (logLower.Contains("ruby") || logLower.Contains(".rb") || logLower.Contains("gem"))
                    return "Ruby";
                if (logLower.Contains("rust") || logLower.Contains("cargo") || logLower.Contains(".rs"))
                    return "Rust";
                if (logLower.Contains("golang") || logLower.Contains("go ") || logLower.Contains(".go"))
                    return "Go";
                if (logLower.Contains("php") || logLower.Contains(".php") || logLower.Contains("composer"))
                    return "PHP";
                if (logLower.Contains("node") || logLower.Contains("npm") || logLower.Contains("javascript"))
                    return "JavaScript";
                if (logLower.Contains("cmake") || logLower.Contains("cmakelists.txt"))
                    return "CMake";
                if (logLower.Contains("meson"))
                    return "Meson";
                if (logLower.Contains("g++") || logLower.Contains("gcc") ||
                   logLower.Contains(".cpp") || logLower.Contains(".cc") ||
                   logLower.Contains(".c++") || logLower.Contains(".cxx"))
                    return "C++";
                if (logLower.Contains(".c") && !logLower.Contains(".cpp") && !logLower.Contains(".cc"))
                    return "C";

                return "Unknown";
            }

            private static string ExtractErrorDetails(string logContent)
            {
                string[] errorKeywords = new[] {
            "error:", "fail", "failed", "failure", "fatal", "cannot", "non-zero exit status",
            "bad exit status", "ошибка", "test summary report", "rpm build errors", "command exited with non-zero status"
        };

                string[] lines = logContent.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);

                var errorLines = new List<string>();

                foreach (var line in lines)
                {
                    string trimmedLine = line.Trim();
                    if (string.IsNullOrEmpty(trimmedLine))
                        continue;

                    foreach (var keyword in errorKeywords)
                    {
                        if (trimmedLine.ToLower().Contains(keyword.ToLower()))
                        {
                            errorLines.Add(trimmedLine);
                            break;
                        }
                    }

                    if (errorLines.Count >= 5)
                        break;
                }

                if (errorLines.Count == 0 && lines.Length > 0)
                {
                    int startIndex = Math.Max(0, lines.Length - 5);
                    errorLines.AddRange(lines.Skip(startIndex).Take(5));
                }

                return string.Join("\n", errorLines);
            }
            private static void RefineErrorBasedOnLanguage(LogAnalysisResult result)
            {
                if (result.Language == "Perl" && result.ErrorType == "Test Error")
                {
                    result.ErrorType = "Perl Test Error";
                    result.SuggestedFix = "Проверьте тесты Perl-модуля, возможно используются устаревшие методы или неправильные данные";
                }
                else if (result.Language == "Python" && result.ErrorType == "Import/Require Error")
                {
                    result.ErrorType = "Python Import Error";
                    result.SuggestedFix = "Убедитесь, что все необходимые Python-модули установлены и доступны";
                }
                else if (result.Language == "Java" && result.ErrorType == "Compile Error")
                {
                    result.ErrorType = "Java Compilation Error";
                    result.SuggestedFix = "Проверьте Java-код на наличие синтаксических ошибок и правильность импортов";
                }
                else if (result.Language == "Rust" && result.ErrorType == "Build Error")
                {
                    result.ErrorType = "Rust Build Error";
                    result.SuggestedFix = "Проверьте Cargo.toml и зависимости Rust-пакета";
                }
            }
            
        }

        public class LogAnalysisResult
        {
            public string ErrorType { get; set; } = "Unknown";
            public string ErrorSubType { get; set; } = "Unknown";
            public string ErrorDetails { get; set; } = "";
            public string Language { get; set; } = "Unknown";
            public string SuggestedFix { get; set; } = "";
            public string LogUrl { get; set; } = "";
            public string RawLog { get; set; } = "";

            public string GetSummary()
            {
                return $"{ErrorType}: {ErrorSubType}\nЯзык: {Language}\n{SuggestedFix}";
            }
        }

        
        private string SuggestFix(string errorMessage)
        {
            if (string.IsNullOrEmpty(errorMessage))
                return "Требуется анализ логов сборки";

            if (errorMessage.Contains("cmake_minimum_required") && errorMessage.Contains("3.5"))
                return "Обновите cmake_minimum_required до версии 3.5 или выше в файле CMakeLists.txt";

            if (errorMessage.Contains("expected old version of build.zig format"))
                return "Обновите формат файла build.zig до нового стандарта";

            if (errorMessage.Contains("No module named 'setuptools'"))
                return "Добавьте python3-setuptools в BuildRequires в spec-файле";

            if (errorMessage.Contains("vector") && errorMessage.Contains("not") && errorMessage.Contains("type"))
                return "Добавьте #include <vector> в исходный код";

            if (errorMessage.Contains("no matching function") && errorMessage.Contains("make_shared"))
                return "Обновите код для совместимости с новой версией C++";

            if (errorMessage.Contains("npm ERR! 404 Not Found"))
                return "Обновите зависимости в package.json";

            if (errorMessage.Contains("package javax.servlet does not exist"))
                return "Добавьте зависимость javax.servlet-api в проект";

            if (errorMessage.Contains("cannot find module"))
                return "Обновите go.mod файл и выполните go mod tidy";

            return "Требуется детальный анализ логов сборки";
        }
    }
}