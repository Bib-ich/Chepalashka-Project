﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using CommunityToolkit.Mvvm.ComponentModel;

namespace Proga1
{
    public partial class ErrorFilterManager : ObservableObject
    {
        [ObservableProperty]
        private List<BuildError> _allErrors = new();

        [ObservableProperty]
        private ObservableCollection<BuildError> _filteredErrors = new();

        [ObservableProperty]
        private ObservableCollection<string> _availableErrorTypes = new();

        [ObservableProperty]
        private ObservableCollection<string> _availableLanguages = new();

        [ObservableProperty]
        private ObservableCollection<string> _availableDates = new();

        [ObservableProperty]
        private string _selectedErrorType = "Все";

        [ObservableProperty]
        private string _selectedLanguage = "Все";

        [ObservableProperty]
        private string _selectedDate = "Все";

        [ObservableProperty]
        private string _searchText = "";

        [ObservableProperty]
        private Dictionary<string, int> _errorTypeStatistics = new();

        [ObservableProperty]
        private Dictionary<string, int> _languageStatistics = new();

        [ObservableProperty]
        private List<ErrorGroup> _errorGroups = new();

        public ErrorFilterManager()
        {
            PropertyChanged += ErrorFilterManager_PropertyChanged;
        }

        private void ErrorFilterManager_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            switch (e.PropertyName)
            {
                case nameof(SelectedErrorType):
                case nameof(SelectedLanguage):
                case nameof(SelectedDate):
                case nameof(SearchText):
                    ApplyFilters();
                    break;

                case nameof(AllErrors):
                    UpdateAvailableFilterValues();
                    UpdateStatistics();
                    ApplyFilters();
                    break;
            }
        }
        public void FilterByErrorType(string errorType)
        {
            SelectedErrorType = errorType;
        }

        public void FilterByLanguage(string language)
        {
            SelectedLanguage = language;
        }
        public void Initialize(List<BuildError> errors)
        {
            AllErrors = errors ?? new List<BuildError>();
        }

        private void UpdateAvailableFilterValues()
        {
            var errorTypes = new List<string> { "Все" };
            errorTypes.AddRange(AllErrors.Select(e => e.ErrorType).Distinct().OrderBy(t => t));
            AvailableErrorTypes = new ObservableCollection<string>(errorTypes);

            var languages = new List<string> { "Все" };
            languages.AddRange(AllErrors.Select(e => e.Language).Distinct().OrderBy(l => l));
            AvailableLanguages = new ObservableCollection<string>(languages);

            var dates = new List<string> { "Все" };
            dates.AddRange(AllErrors.Select(e => e.Timestamp.Date.ToShortDateString()).Distinct().OrderByDescending(d => d));
            AvailableDates = new ObservableCollection<string>(dates);
        }

        private void UpdateStatistics()
        {
            ErrorTypeStatistics = AllErrors
                .GroupBy(e => e.ErrorType)
                .OrderByDescending(g => g.Count())
                .ToDictionary(g => g.Key, g => g.Count());

            LanguageStatistics = AllErrors
                .GroupBy(e => e.Language)
                .OrderByDescending(g => g.Count())
                .ToDictionary(g => g.Key, g => g.Count());
        }

        public void ApplyFilters()
        {
            var query = AllErrors.AsEnumerable();

            if (!string.IsNullOrEmpty(SelectedErrorType) && SelectedErrorType != "Все")
            {
                query = query.Where(e => e.ErrorType == SelectedErrorType);
            }

            if (!string.IsNullOrEmpty(SelectedLanguage) && SelectedLanguage != "Все")
            {
                query = query.Where(e => e.Language == SelectedLanguage);
            }

            if (!string.IsNullOrEmpty(SelectedDate) && SelectedDate != "Все")
            {
                query = query.Where(e => e.Timestamp.Date.ToShortDateString() == SelectedDate);
            }

            if (!string.IsNullOrEmpty(SearchText))
            {
                string searchLower = SearchText.ToLower();
                query = query.Where(e =>
                    e.PackageName.ToLower().Contains(searchLower) ||
                    e.ErrorType.ToLower().Contains(searchLower) ||
                    e.LogMessage.ToLower().Contains(searchLower));
            }

            FilteredErrors = new ObservableCollection<BuildError>(query.ToList());
        }
        public ErrorFilterManager(List<BuildError> errors)
        {
            PropertyChanged += ErrorFilterManager_PropertyChanged;
            Initialize(errors);
        }
        public void ResetFilters()
        {
            SelectedErrorType = "Все";
            SelectedLanguage = "Все";
            SelectedDate = "Все";
            SearchText = "";
        }
    }
}