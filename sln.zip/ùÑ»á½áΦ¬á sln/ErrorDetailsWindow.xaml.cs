﻿
using Proga1;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows;

public class MainWindow : Window
{
    
    public ErrorFilterManager FilterManager { get; private set; }

    
    private void InitializeFilters(List<BuildError> errors)
    {
        FilterManager = new ErrorFilterManager(errors);
        DataContext = this; 

    }

   
    private void ResetFiltersButton_Click(object sender, RoutedEventArgs e)
    {
        FilterManager.ResetFilters();
    }

    private void FilterByErrorTypeButton_Click(object sender, RoutedEventArgs e)
    {
        Button button = sender as Button;
        if (button != null && button.Tag is string errorType)
        {
            FilterManager.FilterByErrorType(errorType);
        }
    }

    private void FilterByLanguageButton_Click(object sender, RoutedEventArgs e)
    {
        Button button = sender as Button;
        if (button != null && button.Tag is string language)
        {
            FilterManager.FilterByLanguage(language);
        }
    }

    private void GenerateReportButton_Click(object sender, RoutedEventArgs e)
    {
        var analyzer = new ErrorAnalyzer();
        string report = analyzer.GenerateStatisticsReport(FilterManager.AllErrors);

        var reportWindow = new Window
        {
            Title = "Отчет по ошибкам сборки",
            Width = 800,
            Height = 600,
            Content = new TextBox
            {
                Text = report,
                IsReadOnly = true,
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                HorizontalScrollBarVisibility = ScrollBarVisibility.Auto,
                FontFamily = new FontFamily("Consolas")
            }
        };

        reportWindow.Show();
    }

    private void SaveResultsButton_Click(object sender, RoutedEventArgs e)
    {
       
        var saveDialog = new Microsoft.Win32.SaveFileDialog
        {
            DefaultExt = ".json",
            Filter = "JSON файлы|*.json|Все файлы|*.*",
            FileName = $"alt_errors_{DateTime.Now:yyyyMMdd}"
        };

        if (saveDialog.ShowDialog() == true)
        {
            ErrorAnalysisStorage.SaveAnalysisResults(FilterManager.AllErrors, saveDialog.FileName);
        }
    }

    private void LoadResultsButton_Click(object sender, RoutedEventArgs e)
    {
        
        var openDialog = new Microsoft.Win32.OpenFileDialog
        {
            DefaultExt = ".json",
            Filter = "JSON файлы|*.json|Все файлы|*.*"
        };

        if (openDialog.ShowDialog() == true)
        {
            var loadedErrors = ErrorAnalysisStorage.LoadAnalysisResults(openDialog.FileName);
            if (loadedErrors.Count > 0)
            {
                
                var result = MessageBox.Show(
                    "Хотите заменить текущие результаты загруженными или объединить их?",
                    "Загрузка результатов",
                    MessageBoxButton.YesNoCancel,
                    MessageBoxImage.Question);

                if (result == MessageBoxResult.Yes)
                {
                    
                    FilterManager.AllErrors = loadedErrors;
                }
                else if (result == MessageBoxResult.No)
                {
                   
                    var mergedErrors = FilterManager.AllErrors.ToList();
                    mergedErrors.AddRange(loadedErrors);
                    FilterManager.AllErrors = mergedErrors;
                }
            }
        }
    }

    private void ViewLogButton_Click(object sender, RoutedEventArgs e)
    {
        Button button = sender as Button;
        if (button != null && button.Tag is string logUrl)
        {
           
            try
            {
                System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo
                {
                    FileName = logUrl,
                    UseShellExecute = true
                });
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при открытии URL: {ex.Message}", "Ошибка");
            }
        }
    }

    private void ViewDetailsButton_Click(object sender, RoutedEventArgs e)
    {
        
        Button button = sender as Button;
        if (button != null)
        {
            var error = button.DataContext as BuildError;
            if (error != null)
            {
               
                var detailsWindow = new Window
                {
                    Title = $"Детали ошибки: {error.PackageName}",
                    Width = 700,
                    Height = 500
                };

                var grid = new Grid();
                grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
                grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

                var scrollViewer = new ScrollViewer();
                var detailsPanel = new StackPanel { Margin = new Thickness(15) };

                
                detailsPanel.Children.Add(new TextBlock
                {
                    Text = "Информация о пакете",
                    FontSize = 18,
                    FontWeight = FontWeights.Bold,
                    Margin = new Thickness(0, 0, 0, 10)
                });

                detailsPanel.Children.Add(CreateDetailRow("Имя пакета:", error.PackageName));
                detailsPanel.Children.Add(CreateDetailRow("Тип ошибки:", error.ErrorType));
                detailsPanel.Children.Add(CreateDetailRow("Язык:", error.Language));
                detailsPanel.Children.Add(CreateDetailRow("Дата:", error.Timestamp.ToString("dd.MM.yyyy HH:mm:ss")));

                detailsPanel.Children.Add(new TextBlock
                {
                    Text = "Сообщение об ошибке",
                    FontSize = 16,
                    FontWeight = FontWeights.Bold,
                    Margin = new Thickness(0, 15, 0, 5)
                });

                detailsPanel.Children.Add(new TextBox
                {
                    Text = error.LogMessage,
                    IsReadOnly = true,
                    TextWrapping = TextWrapping.Wrap,
                    MaxHeight = 150,
                    VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                    Margin = new Thickness(0, 0, 0, 15)
                });

                detailsPanel.Children.Add(new TextBlock
                {
                    Text = "Рекомендации по исправлению",
                    FontSize = 16,
                    FontWeight = FontWeights.Bold,
                    Margin = new Thickness(0, 0, 0, 5)
                });

                detailsPanel.Children.Add(new TextBox
                {
                    Text = error.SuggestedFix,
                    IsReadOnly = true,
                    TextWrapping = TextWrapping.Wrap,
                    Margin = new Thickness(0, 0, 0, 15)
                });

                detailsPanel.Children.Add(new TextBlock
                {
                    Text = "URL лога",
                    FontSize = 16,
                    FontWeight = FontWeights.Bold,
                    Margin = new Thickness(0, 0, 0, 5)
                });

                var urlPanel = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 0, 0, 15) };
                urlPanel.Children.Add(new TextBox
                {
                    Text = error.LogUrl,
                    IsReadOnly = true,
                    Width = 500,
                    Margin = new Thickness(0, 0, 10, 0)
                });

                var openUrlButton = new Button { Content = "Открыть", Padding = new Thickness(10, 0, 10, 0) };
                openUrlButton.Click += (s, args) => {
                    try
                    {
                        System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo
                        {
                            FileName = error.LogUrl,
                            UseShellExecute = true
                        });
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Ошибка при открытии URL: {ex.Message}", "Ошибка");
                    }
                };
                urlPanel.Children.Add(openUrlButton);

                detailsPanel.Children.Add(urlPanel);

                
                detailsPanel.Children.Add(new TextBlock
                {
                    Text = "Похожие ошибки",
                    FontSize = 16,
                    FontWeight = FontWeights.Bold,
                    Margin = new Thickness(0, 0, 0, 5)
                });

                var similarErrors = FilterManager.AllErrors
                    .Where(e => e.ErrorType == error.ErrorType && e.PackageName != error.PackageName)
                    .Take(5)
                    .ToList();

                if (similarErrors.Count > 0)
                {
                    foreach (var similarError in similarErrors)
                    {
                        detailsPanel.Children.Add(new TextBlock
                        {
                            Text = $"• {similarError.PackageName} ({similarError.Language})",
                            Margin = new Thickness(10, 2, 0, 2)
                        });
                    }
                }
                else
                {
                    detailsPanel.Children.Add(new TextBlock
                    {
                        Text = "Не найдено похожих ошибок",
                        Margin = new Thickness(10, 2, 0, 2),
                        Foreground = Brushes.Gray
                    });
                }

                scrollViewer.Content = detailsPanel;
                Grid.SetRow(scrollViewer, 0);
                grid.Children.Add(scrollViewer);

               
                var closeButton = new Button
                {
                    Content = "Закрыть",
                    Padding = new Thickness(10, 5, 10, 5),
                    HorizontalAlignment = HorizontalAlignment.Right,
                    Margin = new Thickness(0, 10, 15, 15)
                };
                closeButton.Click += (s, args) => detailsWindow.Close();
                Grid.SetRow(closeButton, 1);
                grid.Children.Add(closeButton);

                detailsWindow.Content = grid;
                detailsWindow.Show();
            }
        }
    }

   
    private UIElement CreateDetailRow(string label, string value)
    {
        var panel = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 2, 0, 2) };
        panel.Children.Add(new TextBlock { Text = label, Width = 120, FontWeight = FontWeights.SemiBold });
        panel.Children.Add(new TextBlock { Text = value });
        return panel;
    }
}