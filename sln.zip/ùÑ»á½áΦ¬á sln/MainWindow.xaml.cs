﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace Proga1
{
    public partial class MainWindow : Window
    {
        public ErrorFilterManager FilterManager { get; private set; } = new ErrorFilterManager();



        private MainViewModel _viewModel;

        public MainWindow()
        {
            InitializeComponent();
            _viewModel = new MainViewModel();
            DataContext = _viewModel; 
        }

        private void InitializeFilters(List<BuildError> errors)
        {
            FilterManager = new ErrorFilterManager(errors);
            DataContext = this; 
        }

        private void ResetFiltersButton_Click(object sender, RoutedEventArgs e)
        {
            FilterManager.ResetFilters();
        }

        private void FilterByErrorTypeButton_Click(object sender, RoutedEventArgs e)
        {
            Button button = sender as Button;
            if (button != null && button.Tag is string errorType)
            {
                FilterManager.FilterByErrorType(errorType);
            }
        }

        private void FilterByLanguageButton_Click(object sender, RoutedEventArgs e)
        {
            Button button = sender as Button;
            if (button != null && button.Tag is string language)
            {
                FilterManager.FilterByLanguage(language);
            }
        }

        private void GenerateReportButton_Click(object sender, RoutedEventArgs e)
        {
            var analyzer = new ErrorAnalyzer();
            string report = analyzer.GenerateStatisticsReport(FilterManager.AllErrors);

            var reportWindow = new Window
            {
                Title = "Отчет по ошибкам сборки",
                Width = 800,
                Height = 600,
                Content = new TextBox
                {
                    Text = report,
                    IsReadOnly = true,
                    VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                    HorizontalScrollBarVisibility = ScrollBarVisibility.Auto,
                    FontFamily = new FontFamily("Consolas")
                }
            };

            reportWindow.Show();
        }

        private void SaveResultsButton_Click(object sender, RoutedEventArgs e)
        {
            var saveDialog = new Microsoft.Win32.SaveFileDialog
            {
                DefaultExt = ".json",
                Filter = "JSON файлы|*.json|Все файлы|*.*",
                FileName = $"alt_errors_{DateTime.Now:yyyyMMdd}"
            };

            if (saveDialog.ShowDialog() == true)
            {
                ErrorAnalysisStorage.SaveAnalysisResults(FilterManager.AllErrors, saveDialog.FileName);
            }
        }

        private void LoadResultsButton_Click(object sender, RoutedEventArgs e)
        {
            var openDialog = new Microsoft.Win32.OpenFileDialog
            {
                DefaultExt = ".json",
                Filter = "JSON файлы|*.json|Все файлы|*.*"
            };

            if (openDialog.ShowDialog() == true)
            {
                var loadedErrors = ErrorAnalysisStorage.LoadAnalysisResults(openDialog.FileName);
                if (loadedErrors.Count > 0)
                {
                    var result = MessageBox.Show(
                        "Хотите заменить текущие результаты загруженными или объединить их?",
                        "Загрузка результатов",
                        MessageBoxButton.YesNoCancel,
                        MessageBoxImage.Question);

                    if (result == MessageBoxResult.Yes)
                    {
                        FilterManager.AllErrors = loadedErrors;
                    }
                    else if (result == MessageBoxResult.No)
                    {
                        var mergedErrors = FilterManager.AllErrors.ToList();
                        mergedErrors.AddRange(loadedErrors);
                        FilterManager.AllErrors = mergedErrors;
                    }
                }
            }
        }

        private void ViewLogButton_Click(object sender, RoutedEventArgs e)
        {
            Button button = sender as Button;
            if (button != null && button.Tag is string logUrl)
            {
                try
                {
                    System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo
                    {
                        FileName = logUrl,
                        UseShellExecute = true
                    });
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при открытии URL: {ex.Message}", "Ошибка");
                }
            }
        }

        private void ViewDetailsButton_Click(object sender, RoutedEventArgs e)
        {
            Button button = sender as Button;
            if (button != null)
            {
                var error = button.DataContext as BuildError;
                if (error != null)
                {
                    var detailsWindow = new Window
                    {
                        Title = $"Детали ошибки: {error.PackageName}",
                        Width = 700,
                        Height = 500
                    };

                    var grid = new Grid();
                    grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
                    grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });  

                    var scrollViewer = new ScrollViewer();
                    var detailsPanel = new StackPanel { Margin = new Thickness(15) };

                    detailsPanel.Children.Add(new TextBlock
                    {
                        Text = "Информация о пакете",
                        FontSize = 18,
                        FontWeight = FontWeights.Bold,
                        Margin = new Thickness(0, 0, 0, 10)
                    });

                    detailsPanel.Children.Add(CreateDetailRow("Имя пакета:", error.PackageName));
                    detailsPanel.Children.Add(CreateDetailRow("Тип ошибки:", error.ErrorType));
                    detailsPanel.Children.Add(CreateDetailRow("Язык:", error.Language));
                    detailsPanel.Children.Add(CreateDetailRow("Дата:", error.Timestamp.ToString("dd.MM.yyyy HH:mm:ss")));


                    detailsWindow.Content = grid;
                    detailsWindow.ShowDialog();
                }
            }
        }

        private UIElement CreateDetailRow(string label, string value)
        {
            var panel = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 2, 0, 2) };

            panel.Children.Add(new TextBlock
            {
                Text = label,
                Width = 100,
                FontWeight = FontWeights.Bold
            });

            panel.Children.Add(new TextBlock
            {
                Text = value
            });

            return panel;
        }
    }
}