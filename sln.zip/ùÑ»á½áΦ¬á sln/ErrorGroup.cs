﻿using System.Collections.Generic;

namespace Proga1
{
    public class ErrorGroup
    {
        public string GroupName { get; set; }
        public string Description { get; set; }
        public int ErrorCount { get; set; }
        public List<BuildError> Errors { get; set; }
    }
}