﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows; // Для использования Auto в GridLength
using System.Windows.Controls; // Для элементов управления WPF
namespace Proga1
{
    public partial class MainViewModel : ObservableObject
    {
        private readonly ApiService _apiService;
        private readonly ErrorAnalyzer _errorAnalyzer;

        [ObservableProperty]
        private ObservableCollection<ErrorGroup> _errorGroups = new();

        [ObservableProperty]
        private ObservableCollection<BuildError> _allErrors = new();

        [ObservableProperty]
        private ObservableCollection<BuildError> _filteredErrors = new();

        [ObservableProperty]
        private Dictionary<string, int> _languageStatistics = new();

        [ObservableProperty]
        private Dictionary<string, int> _errorTypeStatistics = new();

        [ObservableProperty]
        private string _selectedLanguageFilter = "Все";

        [ObservableProperty]
        private string _selectedErrorTypeFilter = "Все";

        [ObservableProperty]
        private string _searchTerm;

        [ObservableProperty]
        private bool _isLoading;

        [ObservableProperty]
        private ErrorFilterManager _filterManager = new();

        public MainViewModel()
        {
            _apiService = new ApiService();
            _errorAnalyzer = new ErrorAnalyzer();
            LoadDataCommand.Execute(null);
        }

        [RelayCommand]
        private async Task LoadData()
        {
            try
            {
                IsLoading = true;

                // Загружаем данные
                var errors = await _apiService.FetchBuildErrorsAsync();

                // Улучшаем анализ ошибок
                errors = await _apiService.EnhanceErrorsWithAdvancedAnalysis(errors);

                // Инициализируем фильтр-менеджер
                FilterManager.Initialize(errors);

                // Обновляем коллекции для отображения
                AllErrors = new ObservableCollection<BuildError>(errors);

                // Группируем ошибки
                var groups = _errorAnalyzer.GroupErrors(errors);
                ErrorGroups = new ObservableCollection<ErrorGroup>(groups);

                // Обновляем статистику
                LanguageStatistics = BuildErrorStatistics.GetLanguageStatistics(errors);
                ErrorTypeStatistics = BuildErrorStatistics.GetErrorTypeStatistics(errors);

                // Если найдены возможные причины, показываем их
                var possibleCauses = BuildErrorStatistics.DetectPossibleCausesOfErrors(errors);
                if (possibleCauses.Count > 0)
                {
                    string causesMessage = string.Join("\n\n", possibleCauses);
                    MessageBox.Show($"Возможные причины ошибок:\n\n{causesMessage}", "Анализ ошибок",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки данных: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                IsLoading = false;
            }
        }
        [RelayCommand]
        private void ShowErrorDetails(BuildError errorData)
        {
            // Создаем окно с подробной информацией о ошибке
            var errorWindow = new Window
            {
                Title = $"Детали ошибки: {errorData.PackageName}",
                Width = 700,
                Height = 500
            };

            var grid = new Grid();
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
            grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

            var scrollViewer = new ScrollViewer();
            var detailsPanel = new StackPanel { Margin = new Thickness(15) };

            // Добавляем информацию об ошибке
            detailsPanel.Children.Add(new TextBlock
            {
                Text = "Информация о пакете",
                FontSize = 18,
                FontWeight = FontWeights.Bold,
                Margin = new Thickness(0, 0, 0, 10)
            });

            // Заменяем вызовы CreateDetailRow
            detailsPanel.Children.Add(CreateDetailRowInline("Имя пакета:", errorData.PackageName));
            detailsPanel.Children.Add(CreateDetailRowInline("Тип ошибки:", errorData.ErrorType));
            detailsPanel.Children.Add(CreateDetailRowInline("Язык:", errorData.Language));
            detailsPanel.Children.Add(CreateDetailRowInline("Дата:", errorData.Timestamp.ToString("dd.MM.yyyy HH:mm:ss")));

            detailsPanel.Children.Add(new TextBlock
            {
                Text = "Сообщение об ошибке",
                FontSize = 16,
                FontWeight = FontWeights.Bold,
                Margin = new Thickness(0, 15, 0, 5)
            });

            detailsPanel.Children.Add(new TextBox
            {
                Text = errorData.LogMessage,
                IsReadOnly = true,
                TextWrapping = TextWrapping.Wrap,
                MaxHeight = 150,
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                Margin = new Thickness(0, 0, 0, 15)
            });

            // Если есть рекомендации
            if (!string.IsNullOrEmpty(errorData.SuggestedFix))
            {
                detailsPanel.Children.Add(new TextBlock
                {
                    Text = "Рекомендации по исправлению",
                    FontSize = 16,
                    FontWeight = FontWeights.Bold,
                    Margin = new Thickness(0, 0, 0, 5)
                });

                detailsPanel.Children.Add(new TextBox
                {
                    Text = errorData.SuggestedFix,
                    IsReadOnly = true,
                    TextWrapping = TextWrapping.Wrap,
                    Margin = new Thickness(0, 0, 0, 15)
                });
            }

            // Кнопка закрытия
            var closeButton = new Button
            {
                Content = "Закрыть",
                Padding = new Thickness(10, 5, 10, 5),
                HorizontalAlignment = HorizontalAlignment.Right,
                Margin = new Thickness(0, 10, 15, 15)
            };
            closeButton.Click += (s, args) => errorWindow.Close();

            scrollViewer.Content = detailsPanel;
            Grid.SetRow(scrollViewer, 0);
            grid.Children.Add(scrollViewer);

            Grid.SetRow(closeButton, 1);
            grid.Children.Add(closeButton);

            errorWindow.Content = grid;
            errorWindow.ShowDialog();
        }

        private UIElement CreateDetailRowInline(string label, string value)
        {
            var panel = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 2, 0, 2) };
            panel.Children.Add(new TextBlock { Text = label, Width = 120, FontWeight = FontWeights.SemiBold });
            panel.Children.Add(new TextBlock { Text = value });
            return panel;
        }
        [RelayCommand]
        private void ApplyFilters()
        {
            var query = AllErrors.AsEnumerable();

            if (!string.IsNullOrWhiteSpace(SearchTerm))
            {
                query = query.Where(e =>
                    e.PackageName.Contains(SearchTerm, StringComparison.OrdinalIgnoreCase) ||
                    e.ErrorType.Contains(SearchTerm, StringComparison.OrdinalIgnoreCase) ||
                    e.LogMessage.Contains(SearchTerm, StringComparison.OrdinalIgnoreCase));
            }

            if (SelectedLanguageFilter != "Все")
            {
                query = query.Where(e => e.Language == SelectedLanguageFilter);
            }

            if (SelectedErrorTypeFilter != "Все")
            {
                query = query.Where(e => e.ErrorType == SelectedErrorTypeFilter);
            }

            FilteredErrors = new ObservableCollection<BuildError>(query);
        }

        [RelayCommand]
        private void GenerateReport()
        {
            try
            {
                string report = BuildErrorStatistics.GenerateFullReport(AllErrors.ToList());

                var reportWindow = new Window
                {
                    Title = "Отчет по ошибкам сборки",
                    Width = 800,
                    Height = 600,
                    WindowStartupLocation = WindowStartupLocation.CenterScreen
                };

                var reportGrid = new System.Windows.Controls.Grid();
                reportGrid.RowDefinitions.Add(new System.Windows.Controls.RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
                reportGrid.RowDefinitions.Add(new System.Windows.Controls.RowDefinition { Height = GridLength.Auto });

                var textBox = new System.Windows.Controls.TextBox
                {
                    Text = report,
                    IsReadOnly = true,
                    VerticalScrollBarVisibility = System.Windows.Controls.ScrollBarVisibility.Auto,
                    HorizontalScrollBarVisibility = System.Windows.Controls.ScrollBarVisibility.Auto,
                    FontFamily = new System.Windows.Media.FontFamily("Consolas"),
                    Margin = new Thickness(10)
                };
                System.Windows.Controls.Grid.SetRow(textBox, 0);
                reportGrid.Children.Add(textBox);

                var buttonPanel = new System.Windows.Controls.StackPanel
                {
                    Orientation = System.Windows.Controls.Orientation.Horizontal,
                    HorizontalAlignment = HorizontalAlignment.Right,
                    Margin = new Thickness(10, 0, 10, 10)
                };

                var saveButton = new System.Windows.Controls.Button
                {
                    Content = "Сохранить отчет",
                    Padding = new Thickness(10, 5, 10, 5),
                    Margin = new Thickness(0, 0, 10, 0)
                };
                saveButton.Click += (s, e) =>
                {
                    var saveDialog = new SaveFileDialog
                    {
                        Filter = "Текстовые файлы|*.txt|Все файлы|*.*",
                        FileName = $"ALT_BuildErrors_Report_{DateTime.Now:yyyyMMdd}"
                    };

                    if (saveDialog.ShowDialog() == true)
                    {
                        BuildErrorStatistics.SaveReportToFile(report, saveDialog.FileName);
                    }
                };
                buttonPanel.Children.Add(saveButton);

                var closeButton = new System.Windows.Controls.Button
                {
                    Content = "Закрыть",
                    Padding = new Thickness(10, 5, 10, 5)
                };
                closeButton.Click += (s, e) => reportWindow.Close();
                buttonPanel.Children.Add(closeButton);

                System.Windows.Controls.Grid.SetRow(buttonPanel, 1);
                reportGrid.Children.Add(buttonPanel);

                reportWindow.Content = reportGrid;
                reportWindow.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при генерации отчета: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        [RelayCommand]
        private void SaveResults()
        {
            try
            {
                var saveDialog = new SaveFileDialog
                {
                    Filter = "JSON файлы|*.json|Все файлы|*.*",
                    FileName = $"ALT_BuildErrors_{DateTime.Now:yyyyMMdd}"
                };

                if (saveDialog.ShowDialog() == true)
                {
                    ErrorAnalysisStorage.SaveAnalysisResults(AllErrors.ToList(), saveDialog.FileName);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении результатов: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        [RelayCommand]
        private void LoadResults()
        {
            try
            {
                var openDialog = new OpenFileDialog
                {
                    Filter = "JSON файлы|*.json|Все файлы|*.*"
                };

                if (openDialog.ShowDialog() == true)
                {
                    var loadedErrors = ErrorAnalysisStorage.LoadAnalysisResults(openDialog.FileName);

                    if (loadedErrors.Count > 0)
                    {
                        if (AllErrors.Count > 0)
                        {
                            var result = MessageBox.Show(
                                "Хотите заменить текущие результаты загруженными или объединить их?",
                                "Загрузка результатов",
                                MessageBoxButton.YesNoCancel,
                                MessageBoxImage.Question);

                            if (result == MessageBoxResult.Yes)
                            {
                                AllErrors = new ObservableCollection<BuildError>(loadedErrors);
                            }
                            else if (result == MessageBoxResult.No)
                            {
                                var mergedErrors = AllErrors.ToList();
                                mergedErrors.AddRange(loadedErrors);
                                AllErrors = new ObservableCollection<BuildError>(mergedErrors);
                            }
                            else
                            {
                                return; 
                            }
                        }
                        else
                        {
                            AllErrors = new ObservableCollection<BuildError>(loadedErrors);
                        }

                        var groups = _errorAnalyzer.GroupErrors(AllErrors.ToList());
                        ErrorGroups = new ObservableCollection<ErrorGroup>(groups);

                        LanguageStatistics = BuildErrorStatistics.GetLanguageStatistics(AllErrors.ToList());
                        ErrorTypeStatistics = BuildErrorStatistics.GetErrorTypeStatistics(AllErrors.ToList());

                        FilterManager.Initialize(AllErrors.ToList());

                        ApplyFilters();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке результатов: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}