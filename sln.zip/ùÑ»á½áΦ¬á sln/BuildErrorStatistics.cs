﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Windows;

namespace Proga1
{
    public static class BuildErrorStatistics
    {
        public static Dictionary<string, int> GetErrorTypeStatistics(List<BuildError> errors)
        {
            return errors
                .GroupBy(e => e.ErrorType)
                .OrderByDescending(g => g.Count())
                .ToDictionary(g => g.Key, g => g.Count());
        }

        public static Dictionary<string, int> GetLanguageStatistics(List<BuildError> errors)
        {
            return errors
                .GroupBy(e => e.Language)
                .OrderByDescending(g => g.Count())
                .ToDictionary(g => g.Key, g => g.Count());
        }

        public static Dictionary<string, int> GetErrorsByDate(List<BuildError> errors)
        {
            return errors
                .GroupBy(e => e.Timestamp.Date.ToShortDateString())
                .OrderByDescending(g => DateTime.ParseExact(g.Key, "dd.MM.yyyy", null))
                .ToDictionary(g => g.Key, g => g.Count());
        }

        public static List<string> DetectPossibleCausesOfErrors(List<BuildError> errors)
        {
            var results = new List<string>();

            var dateStats = errors
                .GroupBy(e => e.Timestamp.Date)
                .ToDictionary(g => g.Key, g => g.Count());

            var highErrorDates = dateStats
                .OrderByDescending(kv => kv.Value)
                .Where(kv => kv.Value > 10)
                .Take(3)
                .ToList();

            foreach (var dateEntry in highErrorDates)
            {
                var errorsOnDate = errors.Where(e => e.Timestamp.Date == dateEntry.Key).ToList();
                var commonErrorTypes = errorsOnDate
                    .GroupBy(e => e.ErrorType)
                    .OrderByDescending(g => g.Count())
                    .Take(2)
                    .ToList();

                foreach (var errorType in commonErrorTypes)
                {
                    if (errorType.Count() >= 5)
                    {
                        results.Add($"Дата {dateEntry.Key.ToShortDateString()}: {errorType.Count()} ошибок типа '{errorType.Key}'. Возможно, было обновление, затрагивающее эти пакеты.");
                    }
                }
            }

            var languageStats = GetLanguageStatistics(errors);
            var problematicLanguages = languageStats
                .Where(kv => kv.Value > 5)
                .OrderByDescending(kv => kv.Value)
                .Take(3)
                .ToList();

            foreach (var langEntry in problematicLanguages)
            {
                var errorsInLang = errors.Where(e => e.Language == langEntry.Key).ToList();
                var commonErrorTypesInLang = errorsInLang
                    .GroupBy(e => e.ErrorType)
                    .OrderByDescending(g => g.Count())
                    .Take(2)
                    .ToList();

                foreach (var errorType in commonErrorTypesInLang)
                {
                    if (errorType.Count() >= 3)
                    {
                        results.Add($"Язык {langEntry.Key}: {errorType.Count()} ошибок типа '{errorType.Key}'. Возможно, было обновление инструментов или библиотек для {langEntry.Key}.");
                    }
                }
            }

            if (results.Count < 3)
            {
                var topErrors = GetErrorTypeStatistics(errors)
                    .Take(3)
                    .ToList();

                foreach (var error in topErrors)
                {
                    results.Add($"Распространенная ошибка: {error.Value} случаев '{error.Key}'. Рекомендуется проверить общие зависимости этих пакетов.");
                }
            }

            return results;
        }

        public static string GenerateFullReport(List<BuildError> errors)
        {
            var report = new StringBuilder();

            report.AppendLine("=== ОТЧЕТ ПО ОШИБКАМ СБОРКИ ПАКЕТОВ ===");
            report.AppendLine($"Дата формирования: {DateTime.Now}");
            report.AppendLine($"Всего проанализировано ошибок: {errors.Count}");
            report.AppendLine();

            report.AppendLine("== Распределение по типам ошибок ==");
            foreach (var entry in GetErrorTypeStatistics(errors))
            {
                report.AppendLine($"{entry.Key}: {entry.Value} ({Math.Round((double)entry.Value / errors.Count * 100, 1)}%)");
            }
            report.AppendLine();

            report.AppendLine("== Распределение по языкам программирования ==");
            foreach (var entry in GetLanguageStatistics(errors))
            {
                report.AppendLine($"{entry.Key}: {entry.Value} ({Math.Round((double)entry.Value / errors.Count * 100, 1)}%)");
            }
            report.AppendLine();

            report.AppendLine("== Распределение по датам ==");
            foreach (var entry in GetErrorsByDate(errors).Take(10))
            {
                report.AppendLine($"{entry.Key}: {entry.Value} ошибок");
            }
            report.AppendLine();

            report.AppendLine("== ТОП-10 пакетов с ошибками ==");
            var recentErrors = errors
                .OrderByDescending(e => e.Timestamp)
                .Take(10)
                .ToList();

            foreach (var error in recentErrors)
            {
                report.AppendLine($"[{error.Timestamp.ToShortDateString()}] {error.PackageName} - {error.ErrorType} ({error.Language})");

                string logMessageFirstLine = error.LogMessage.Split('\n')[0];
                if (logMessageFirstLine.Length > 100)
                    logMessageFirstLine = logMessageFirstLine.Substring(0, 100) + "...";

                report.AppendLine($"  {logMessageFirstLine}");
                report.AppendLine($"  Рекомендация: {error.SuggestedFix}");
                report.AppendLine();
            }

            report.AppendLine("== Возможные корреляции и причины ошибок ==");
            foreach (var cause in DetectPossibleCausesOfErrors(errors))
            {
                report.AppendLine(cause);
            }

            return report.ToString();
        }
        public static void SaveReportToFile(string report, string filePath)
        {
            try
            {
                File.WriteAllText(filePath, report);
                MessageBox.Show($"Отчет успешно сохранен в {filePath}", "Сохранение отчета",
                    MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении отчета: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        public static void ExportErrorsToJson(List<BuildError> errors, string filePath)
        {
            try
            {
                var exportData = errors.Select(e => new
                {
                    e.PackageName,
                    e.ErrorType,
                    e.LogMessage,
                    e.Language,
                    e.SuggestedFix,
                    e.LogUrl,
                    Timestamp = e.Timestamp.ToString("yyyy-MM-dd HH:mm:ss")
                }).ToList();

                var options = new JsonSerializerOptions
                {
                    WriteIndented = true
                };

                string jsonData = JsonSerializer.Serialize(exportData, options);
                File.WriteAllText(filePath, jsonData);

                MessageBox.Show($"Данные успешно экспортированы в {filePath}", "Экспорт завершен",
                    MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при экспорте данных: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}