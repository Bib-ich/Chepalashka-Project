﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Proga1
{
    public static class ErrorPatternAnalyzer
    {
        private class ErrorPattern
        {
            public string Name { get; set; }
            public string Type { get; set; }
            public string SubType { get; set; }
            public Regex Pattern { get; set; }
            public string SuggestedFix { get; set; }
            public string Language { get; set; }
        }

        private static readonly List<ErrorPattern> KnownPatterns = new List<ErrorPattern>
        {
            new ErrorPattern {
                Name = "CMake Minimum Version",
                Type = "CMake Configuration Error",
                SubType = "Minimum Version",
                Pattern = new Regex(@"CMake\s+(?:Error|Warning).*(?:minimum|min).*version.*(?:3\.[0-9]+|2\.[0-9]+)"),
                SuggestedFix = "Обновите cmake_minimum_required до версии 3.5 или выше. Например: cmake_minimum_required(VERSION 3.5)",
                Language = "CMake"
            },

            new ErrorPattern {
                Name = "CMake Policy",
                Type = "CMake Policy Error",
                SubType = "Policy Setting",
                Pattern = new Regex(@"CMake\s+(?:Error|Warning).*policy\s+CMP\d+"),
                SuggestedFix = "Установите политику CMake с помощью cmake_policy(SET CMP{НОМЕР} NEW)",
                Language = "CMake"
            },
            
            new ErrorPattern {
                Name = "Python Import Error",
                Type = "Python Import Error",
                SubType = "Module Not Found",
                Pattern = new Regex(@"(?:ImportError|ModuleNotFoundError).*No module named\s+['""]([^'""]+)['""]"),
                SuggestedFix = "Добавьте зависимость на Python-модуль. В spec-файле добавьте: BuildRequires: python3-module-{ИМЯ_МОДУЛЯ}",
                Language = "Python"
            },

            new ErrorPattern {
                Name = "Python Syntax Error",
                Type = "Python Syntax Error",
                SubType = "Invalid Syntax",
                Pattern = new Regex(@"SyntaxError:.*(?:invalid syntax|unexpected)"),
                SuggestedFix = "Код содержит синтаксическую ошибку. Проверьте совместимость с версией Python в ALT",
                Language = "Python"
            },
            
            new ErrorPattern {
                Name = "Perl Undefined Value",
                Type = "Perl Runtime Error",
                SubType = "Undefined Value",
                Pattern = new Regex(@"(?:Can't|Cannot)\s+use\s+(?:an\s+)?undefined\s+value"),
                SuggestedFix = "В Perl-коде используется неопределенное значение. Проверьте на null перед использованием",
                Language = "Perl"
            },

            new ErrorPattern {
                Name = "Perl Test Failure",
                Type = "Perl Test Error",
                SubType = "Test Assertion Failed",
                Pattern = new Regex(@"(?:Failed\s+test|Test\s+returned:\s+[1-9]).*at\s+t\/.*\.t\s+line\s+\d+"),
                SuggestedFix = "Тесты Perl-модуля не проходят. Проверьте изменения в зависимостях или отключите тесты в %check",
                Language = "Perl"
            },

            new ErrorPattern {
                Name = "Perl Module Missing",
                Type = "Perl Dependency Error",
                SubType = "Module Not Found",
                Pattern = new Regex(@"(?:Can't\s+locate|Failed\s+to\s+load\s+module)\s+([A-Za-z0-9:]+)\.pm"),
                SuggestedFix = "Отсутствует Perl-модуль. Добавьте в BuildRequires: perl({ИМЯ_МОДУЛЯ})",
                Language = "Perl"
            },
            
            new ErrorPattern {
                Name = "C++ Undefined Reference",
                Type = "C++ Linker Error",
                SubType = "Undefined Reference",
                Pattern = new Regex(@"undefined\s+reference\s+to\s+[`']([^'`]+)[`']"),
                SuggestedFix = "Ошибка линковки. Проверьте доступность нужных библиотек и добавьте соответствующие флаги в LDFLAGS",
                Language = "C++"
            },

            new ErrorPattern {
                Name = "GCC Error",
                Type = "C/C++ Compilation Error",
                SubType = "Compiler Error",
                Pattern = new Regex(@"(?:error:|fatal\s+error:)\s+([^:]+):"),
                SuggestedFix = "Ошибка компиляции. Проверьте соответствие кода стандарту языка и наличие всех заголовочных файлов",
                Language = "C++"
            },
            
            new ErrorPattern {
                Name = "Java Class Not Found",
                Type = "Java Compilation Error",
                SubType = "Class Not Found",
                Pattern = new Regex(@"(?:ClassNotFoundException|NoClassDefFoundError):\s+([A-Za-z0-9_.]+)"),
                SuggestedFix = "Отсутствует Java-класс. Проверьте CLASSPATH и зависимости в BuildRequires",
                Language = "Java"
            },
            
            new ErrorPattern {
                Name = "Missing Dependency",
                Type = "Dependency Error",
                SubType = "Package Not Found",
                Pattern = new Regex(@"(?:No\s+package|not\s+found|cannot\s+find)\s+['""]([^'""]+)['""]"),
                SuggestedFix = "Отсутствует зависимость. Добавьте соответствующий пакет в BuildRequires",
                Language = "Unknown"
            },

            new ErrorPattern {
                Name = "Build Timeout",
                Type = "Build Timeout",
                SubType = "Exceeded Time Limit",
                Pattern = new Regex(@"(?:timeout|timed\s+out|time\s+limit\s+exceeded)"),
                SuggestedFix = "Превышено время сборки. Возможно, есть бесконечный цикл или очень долгий тест",
                Language = "Unknown"
            },
            
            new ErrorPattern {
                Name = "Zig Project Format",
                Type = "Zig Error",
                SubType = "Project Format",
                Pattern = new Regex(@"(?:zig|error).*(?:project|build\.zig).*(?:format|version|layout)"),
                SuggestedFix = "Устаревший формат проекта Zig. Обновите файл описания проекта до нового формата",
                Language = "Zig"
            }
        };

        public static (string ErrorType, string SubType, string SuggestedFix, string Language) AnalyzeLogWithPatterns(string logContent, string packageName)
        {
            if (string.IsNullOrEmpty(logContent))
                return ("Unknown Error", "Empty Log", "Лог пуст, невозможно определить причину", "Unknown");

            string normalizedLog = logContent.ToLower().Replace("\r\n", "\n").Replace("\r", "\n");

            foreach (var pattern in KnownPatterns)
            {
                if (pattern.Pattern.IsMatch(normalizedLog))
                {
                    return (pattern.Type, pattern.SubType, pattern.SuggestedFix, pattern.Language);
                }
            }

            return AnalyzeLogGeneric(logContent, packageName);
        }

        private static (string ErrorType, string SubType, string SuggestedFix, string Language) AnalyzeLogGeneric(string logContent, string packageName)
        {
            string logLower = logContent.ToLower();
            string language = DetectLanguageFromLog(logContent, packageName);

            if (logLower.Contains("test") && (logLower.Contains("fail") || logLower.Contains("error")))
            {
                return ("Test Error", "Test Failure",
                       "Тесты не проходят. Проверьте изменения в зависимостях или отключите проблемные тесты",
                       language);
            }

            if (logLower.Contains("cmake") || logLower.Contains("cmakelists.txt"))
            {
                return ("CMake Error", "Configuration",
                       "Ошибка в конфигурации CMake. Проверьте совместимость с текущей версией CMake",
                       "CMake");
            }

            if (logLower.Contains("configure: error") || logLower.Contains("config.status: error"))
            {
                return ("Configure Error", "Autotools",
                       "Ошибка конфигурации. Проверьте параметры ./configure и зависимости",
                       language);
            }

            if (logLower.Contains("install") && (logLower.Contains("fail") || logLower.Contains("error")))
            {
                return ("Install Error", "Installation",
                       "Ошибка при установке. Проверьте права доступа и пути установки",
                       language);
            }

            if (logLower.Contains("make") && (logLower.Contains("fail") || logLower.Contains("error") || logLower.Contains("***")))
            {
                return ("Make Error", "Build Process",
                       "Ошибка при сборке. Проверьте исходный код на ошибки компиляции",
                       language);
            }

            if (logLower.Contains("dependency") || logLower.Contains("missing") || logLower.Contains("not found"))
            {
                return ("Dependency Error", "Missing Dependency",
                       "Отсутствует зависимость. Проверьте и добавьте необходимые пакеты в BuildRequires",
                       language);
            }

            return ("Build Failed", "Unknown Error",
                   "Неизвестная ошибка сборки. Требуется ручной анализ лога",
                   language);
        }

        private static string DetectLanguageFromLog(string logContent, string packageName)
        {
            string packageLower = packageName.ToLower();
            string logLower = logContent.ToLower();

            if (packageLower.StartsWith("perl-") || logLower.Contains("perl") || logLower.Contains(".pm"))
                return "Perl";

            if (packageLower.StartsWith("python") || logLower.Contains("python") || logLower.Contains(".py"))
                return "Python";

            if (packageLower.StartsWith("ruby") || logLower.Contains("ruby") || logLower.Contains(".rb"))
                return "Ruby";

            if (packageLower.Contains("java") || logLower.Contains("java") || logLower.Contains(".jar"))
                return "Java";

            if (packageLower.StartsWith("rust-") || logLower.Contains("rust") || logLower.Contains("cargo"))
                return "Rust";

            if (packageLower.StartsWith("golang-") || logLower.Contains("go ") || logLower.Contains("golang"))
                return "Go";

            if (logLower.Contains("gcc") || logLower.Contains("g++") ||
                logLower.Contains(".c:") || logLower.Contains(".cpp:"))
                return "C++";

            if (logLower.Contains("cmake") || logLower.Contains("cmakelists.txt"))
                return "CMake";

            if (packageLower.Contains("node") || packageLower.Contains("js-") ||
                logLower.Contains("npm") || logLower.Contains("node.js"))
                return "JavaScript";

            if (packageLower.Contains("php") || logLower.Contains("php"))
                return "PHP";

            return "Unknown";
        }

        public static async Task EnhanceErrorWithLogAnalysisAsync(BuildError error)
        {
            if (string.IsNullOrEmpty(error.LogUrl))
                return;

            try
            {
                using (var client = new HttpClient())
                {
                    client.Timeout = TimeSpan.FromSeconds(10);
                    string logContent = await client.GetStringAsync(error.LogUrl);

                    var (errorType, subType, suggestedFix, language) = AnalyzeLogWithPatterns(logContent, error.PackageName);

                    error.ErrorType = errorType;
                    error.SuggestedFix = suggestedFix;
                    if (language != "Unknown")
                        error.Language = language;

                    error.LogMessage = ExtractMostRelevantLogPart(logContent);
                }
            }
            catch
            {
            }
        }

        private static string ExtractMostRelevantLogPart(string logContent)
        {
            if (string.IsNullOrEmpty(logContent))
                return "Лог недоступен";

            string[] lines = logContent.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);

            List<string> errorLines = new List<string>();
            string[] errorKeywords = { "error:", "ERROR:", "fail", "FAIL", "failed", "FAILED",
                                      "cannot", "CANNOT", "fatal", "FATAL", "undefined", "UNDEFINED" };

            foreach (string line in lines)
            {
                if (errorKeywords.Any(kw => line.Contains(kw)))
                {
                    errorLines.Add(line.Trim());

                    int lineIndex = Array.IndexOf(lines, line);
                    for (int i = 1; i <= 3; i++)
                    {
                        if (lineIndex + i < lines.Length)
                            errorLines.Add(lines[lineIndex + i].Trim());
                    }

                    if (errorLines.Count >= 10)
                        break;
                }
            }

            if (errorLines.Count == 0 && lines.Length > 0)
            {
                int startIndex = Math.Max(0, lines.Length - 5);
                for (int i = startIndex; i < lines.Length; i++)
                {
                    errorLines.Add(lines[i].Trim());
                }
            }

            return string.Join("\n", errorLines);
        }
    }
}