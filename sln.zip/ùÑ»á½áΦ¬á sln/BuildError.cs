﻿using System;
using static Proga1.ApiService;

namespace Proga1 {
    public class BuildError
    {
        public string PackageName { get; set; }
        public string ErrorType { get; set; }  
        public string ErrorSubType { get; set; } 
        public string LogMessage { get; set; }
        public DateTime Timestamp { get; set; }
        public string Language { get; set; }
        public string SuggestedFix { get; set; }
        public string LogUrl { get; set; }

        public LogAnalysisResult LogAnalysis { get; set; }

        public async Task AnalyzeLogAsync()
        {
            if (string.IsNullOrEmpty(LogUrl))
                return;

            LogAnalysis = await LogAnalyzer.AnalyzeLogAsync(LogUrl);

            if (LogAnalysis != null)
            {
                ErrorType = LogAnalysis.ErrorType;
                ErrorSubType = LogAnalysis.ErrorSubType;
                Language = LogAnalysis.Language != "Unknown" ? LogAnalysis.Language : Language;
                SuggestedFix = LogAnalysis.SuggestedFix;
            }
        }
    }
}