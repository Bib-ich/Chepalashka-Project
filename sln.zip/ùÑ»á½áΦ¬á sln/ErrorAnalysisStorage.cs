﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Windows;

namespace Proga1
{
    public static class ErrorAnalysisStorage
    {
        public static void SaveAnalysisResults(List<BuildError> errors, string filePath)
        {
            try
            {
                var dataToSave = new
                {
                    SaveDate = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"),
                    ErrorCount = errors.Count,
                    Errors = errors.Select(e => new
                    {
                        e.PackageName,
                        e.ErrorType,
                        e.LogMessage,
                        e.Language,
                        e.SuggestedFix,
                        e.LogUrl,
                        Timestamp = e.Timestamp.ToString("yyyy-MM-dd HH:mm:ss")
                    }).ToList()
                };

                var options = new JsonSerializerOptions
                {
                    WriteIndented = true
                };

                string jsonData = JsonSerializer.Serialize(dataToSave, options);
                File.WriteAllText(filePath, jsonData);

                MessageBox.Show($"Анализ успешно сохранен в {filePath}", "Сохранение завершено",
                    MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении анализа: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        public static List<BuildError> LoadAnalysisResults(string filePath)
        {
            try
            {
                if (!File.Exists(filePath))
                {
                    MessageBox.Show($"Файл не найден: {filePath}", "Ошибка",
                        MessageBoxButton.OK, MessageBoxImage.Error);
                    return new List<BuildError>();
                }

                string jsonData = File.ReadAllText(filePath);
                using (JsonDocument document = JsonDocument.Parse(jsonData))
                {
                    var errors = new List<BuildError>();
                    var errorsArray = document.RootElement.GetProperty("Errors");

                    foreach (var errorElement in errorsArray.EnumerateArray())
                    {
                        string packageName = errorElement.GetProperty("PackageName").GetString();
                        string errorType = errorElement.GetProperty("ErrorType").GetString();
                        string logMessage = errorElement.GetProperty("LogMessage").GetString();
                        string language = errorElement.GetProperty("Language").GetString();
                        string suggestedFix = errorElement.GetProperty("SuggestedFix").GetString();
                        string logUrl = errorElement.GetProperty("LogUrl").GetString();
                        string timestampStr = errorElement.GetProperty("Timestamp").GetString();

                        DateTime timestamp = DateTime.Parse(timestampStr);

                        errors.Add(new BuildError
                        {
                            PackageName = packageName,
                            ErrorType = errorType,
                            LogMessage = logMessage,
                            Language = language,
                            SuggestedFix = suggestedFix,
                            LogUrl = logUrl,
                            Timestamp = timestamp
                        });
                    }

                    MessageBox.Show($"Загружено {errors.Count} ошибок из {filePath}", "Загрузка завершена",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                    return errors;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке анализа: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
                return new List<BuildError>();
            }
        }

        public static void AutoSaveAnalysisResults(List<BuildError> errors)
        {
            try
            {
                string autoSaveDir = Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                    "ALT_FTBFS_Analyzer");

                if (!Directory.Exists(autoSaveDir))
                {
                    Directory.CreateDirectory(autoSaveDir);
                }

                string fileName = $"autosave_{DateTime.Now:yyyyMMdd_HHmmss}.json";
                string filePath = Path.Combine(autoSaveDir, fileName);

                SaveAnalysisResults(errors, filePath);

                var files = Directory.GetFiles(autoSaveDir, "autosave_*.json")
                    .OrderByDescending(f => f)
                    .Skip(5)
                    .ToList();

                foreach (var file in files)
                {
                    try { File.Delete(file); } catch { }
                }
            }
            catch
            {
            }
        }
    }
}